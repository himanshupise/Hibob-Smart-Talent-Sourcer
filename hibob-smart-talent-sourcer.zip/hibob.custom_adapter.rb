{
  title: 'HiBob',

  connection: {
    fields: [
      {
        name: 'user_id', label: 'Service user ID',
        optional: false,
        hint: "Refer <a href = 'https://apidocs.hibob.com/docs/api-" \
              "service-users', target = '_blank'>API documentation</a> " \
              'for more information about Service users'
      },
      {
        name: 'user_token', label: 'Service user token',
        control_type: 'password',
        optional: false,
        hint: "Refer <a href = 'https://apidocs.hibob.com/docs/api-service-" \
              "users#how-to-create-a-new-service-user', target = " \
              "'_blank'>API documentation</a> " \
              'to generate/find Service token'
      },
      {
        name: 'environment',
        optional: false,
        control_type: :select,
        default: 'https://api.hibob.com',
        options: [
          %w[Production https://api.hibob.com],
          %w[Sandbox https://api.sandbox.hibob.com]
        ]
      },
      {
        name: 'partner_token',
        hint: 'Used for Partner accounts. To obtain the Partner token, ' \
              'login to your Partner Stack account → Under the Hibob Program → ' \
              'on the left sidebar, click on My Profile → under Partner-Token.'
      }
    ],
    authorization: {
      type: 'custom_auth',

      acquire: lambda do |connection|
        token = "#{connection['user_id']}:#{connection['user_token']}".
                encode_base64
        { companyId: post("#{connection['environment']}/v1/people/search").
          payload({}).
          headers(Authorization: "Basic #{token}")&.dig('employees', 0, 'companyId'),
          token: token }
      end,

      refresh_on: [401],

      apply: lambda do |connection|
        headers(Authorization: "Basic #{connection['token']}")
        if connection['partner_token'].present?
          case_sensitive_headers('Partner-Token': connection['partner_token'])
        end
      end
    },
    base_uri: lambda do |connection|
      connection['environment'].presence || 'https://api.hibob.com'
    end
  },

  test: lambda do |_connection|
    get('/v1/company/named-lists').
      after_error_response(/.*/) do |_code, body, _header, message|
        error("#{message}: #{body}")
      end
  end,

  object_definitions: {
    time_off_request_output: {
      fields: lambda do |_conneciton, _config_fields|
        [
          {
            convert_output: 'float_conversion',
            type: 'number',
            name: 'requestId'
          },
          {
            name: 'employeeId'
          },
          {
            name: 'changeType'
          },
          {
            control_type: 'number',
            convert_output: 'float_conversion',
            type: 'number',
            name: 'totalDuration'
          },
          {
            name: 'policyTypeDisplayName'
          },
          {
            name: 'changeReason'
          },
          {
            name: 'endDate',
            type: 'date'
          },
          {
            name: 'employeeEmail'
          },
          {
            name: 'type'
          },
          {
            name: 'startPortion'
          },
          {
            name: 'employeeDisplayName'
          },
          {
            name: 'durationUnit'
          },
          {
            name: 'endPortion'
          },
          {
            convert_output: 'float_conversion',
            type: 'number',
            name: 'totalCost'
          },
          {
            name: 'startDate',
            type: 'date'
          },
          {
            name: 'date',
            type: 'date'
          },
          {
            name: 'hoursOnDate',
            type: 'integer',
            convert_output: 'integer_conversion'
          },
          {
            name: 'dailyHours',
            convert_output: 'float_conversion',
            type: 'number'
          },
          { name: 'dayPortion' }
        ]
      end
    },
    search_records_input: {
      fields: lambda do |_conneciton, config_fields|
        next [] if config_fields.blank?

        if %w[employee_work_history employee_employment_history
              employee_life_cycle_history employee_salary_history].
           include?(config_fields['object'])
          [
            { name: 'id', label: 'Employee ID',
              optional: false }
          ]
        elsif %w[company_list company_report
                 company_field onboarding_wizard].include?(config_fields['object'])
          []
        else
          call("#{config_fields['object']}_search_input", config_fields)
        end
      end
    },
    search_records_output: {
      fields: lambda do |_conneciton, config_fields|
        next [] if config_fields.blank?

        config_fields['object'] = 'employees' if config_fields['object'] == 'employees_new'

        base_fields = if %w[timeoff task employees].include?(config_fields['object'])
                        call("#{config_fields['object']}_search_output", config_fields)
                      else
                        call("#{config_fields['object']}_search_output")
                      end

        call('add_rate_limit_fields', base_fields)
      end
    },
    get_record_input: {
      fields: lambda do |_conneciton, config_fields|
        next [] if config_fields.blank?

        call("#{config_fields['object']}_get_input")
      end
    },
    get_record_output: {
      fields: lambda do |_conneciton, config_fields|
        next [] if config_fields.blank?

        config_fields['object'] = 'employee' if config_fields['object'] == 'employee_new'

        base_fields = if %w[company_list timeoff].include?(config_fields['object'])
                        call("#{config_fields['object']}_get_output")
                      else
                        call("#{config_fields['object']}_get_output", config_fields)
                      end
        call('add_rate_limit_fields', base_fields)
      end
    },
    webhook_output_schema: {
      fields: lambda do |_conneciton, config_fields|
        next [] if config_fields.blank?

        if config_fields['event'] == 'employee' && config_fields['event_type'] == 'employee.updated'
          call("#{config_fields['event']}_updated_trigger_output")
        elsif config_fields['event'] == 'task' &&
              config_fields['event_type'] == 'todo.changedStatus'
          call("#{config_fields['event']}_status_changed_trigger_output")
        else
          call("#{config_fields['event']}_trigger_output")
        end
      end
    },
    webhook_v2_output_schema: {
      fields: lambda do |_conneciton, config_fields|
        next [] if config_fields.blank?

        [
          { name: 'companyId', type: 'integer' },
          { name: 'type' },
          { name: 'triggeredBy' },
          { name: 'triggeredAt', type: 'date_time' },
          { name: 'version' },
          {
            name: 'data',
            type: 'object',
            properties: call('webhook_v2_data_schema', config_fields['event'],
                             config_fields['event_type'])
          }
        ]
      end
    },
    update_record_input: {
      fields: lambda do |_conneciton, config_fields|
        next [] if config_fields.blank?

        call("#{config_fields['object']}_update_input")
      end
    },
    create_record_input: {
      fields: lambda do |_conneciton, config_fields|
        next [] if config_fields.blank?

        call("#{config_fields['object']}_create_input")
      end
    },
    create_record_output: {
      fields: lambda do |_conneciton, config_fields|
        next [] if config_fields.blank?

        base_fields = if %w[company_list_item timeoff_request].include?(config_fields['object'])
                        [
                          { name: 'id' }
                        ]
                      else
                        []
                      end

        call('add_rate_limit_fields', base_fields)
      end
    },
    update_record_output: {
      fields: lambda do |_conneciton, config_fields|
        next [] if config_fields.blank?

        base_fields = []
        call('add_rate_limit_fields', base_fields)
      end
    },
    delete_record_output: {
      fields: lambda do |_conneciton, config_fields|
        next [] if config_fields.blank?

        base_fields = []
        call('add_rate_limit_fields', base_fields)
      end
    },
    revoke_access_output: {
      fields: lambda do |_conneciton, _config_fields|
        base_fields = []
        call('add_rate_limit_fields', base_fields)
      end
    },
    invite_employee_output: {
      fields: lambda do |_conneciton, _config_fields|
        base_fields = []
        call('add_rate_limit_fields', base_fields)
      end
    },
    make_task_complete_output: {
      fields: lambda do |_conneciton, config_fields|
        next [] if config_fields.blank?

        base_fields = [
          { name: 'toDosUpdated', type: 'integer' }
        ]
        call('add_rate_limit_fields', base_fields)
      end
    },
    download_report_output: {
      fields: lambda do |_conneciton, config_fields|
        next [] if config_fields.blank?

        base_fields = [
          { name: 'file_content', label: 'File contents' }
        ]
        call('add_rate_limit_fields', base_fields)
      end
    },
    upload_document_output: {
      fields: lambda do |_conneciton, config_fields|
        next [] if config_fields.blank?

        base_fields = [
          { name: 'id' }
        ]
        call('add_rate_limit_fields', base_fields)
      end
    },
    download_report_input: {
      fields: lambda do
        [
          { name: 'reportId', optional: false },
          { name: 'format', optional: false,
            control_type: 'select',
            pick_list: %w[json csv xlsx].map { |e| [e.upcase, e] },
            toggle_hint: 'Select from list',
            toggle_field: {
              name: 'format', label: 'Format',
              type: 'string', control_type: 'text',
              optional: false, sticky: true,
              hint: "Allowed values are 'json', 'csv' and 'xlsx'.",
              toggle_hint: 'Use custom value'
            } },
          { name: 'includeInfo', sticky: true,
            type: 'boolean', control_type: 'checkbox',
            convert_input: 'boolean_conversion',
            toggle_hint: 'Select from list',
            toggle_field: {
              name: 'includeInfo', label: 'Include info',
              type: 'string', control_type: 'text',
              optional: true, sticky: true,
              convert_input: 'boolean_conversion',
              hint: 'Accepted values are true or false',
              toggle_hint: 'Use custom value'
            } },
          { name: 'locale', sticky: true,
            hint: 'Requested language for the report columns in the format ' \
                  'of locale (e.g. fr-FR), if not provided, the user ' \
                  'preferences locale is used.' }
        ]
      end
    },
    delete_record_input: {
      fields: lambda do |_conneciton, config_fields|
        next [] if config_fields.blank?

        case config_fields['object']

        when 'timeoff_request'
          [
            { name: 'id', label: 'Employee ID',
              optional: false },
            { name: 'requestId', optional: false,
              type: 'integer', control_type: 'integer',
              convert_input: 'integer_conversion' }
          ]
        when 'company_list_item'
          [
            { name: 'listName', optional: false,
              hint: 'Internal name of the list' },
            { name: 'itemId', optional: false,
              hint: 'ID of the list item' }
          ]
        when 'document'
          [
            { name: 'folder_type', optional: false,
              control_type: 'select',
              pick_list: %w[shared confidential].map { |e| [e.labelize, e] } },
            { name: 'id', label: 'Employee ID',
              optional: false },
            { name: 'docId', label: 'Document ID',
              optional: false }
          ]
        else
          [
            { name: 'id', label: 'Employee ID',
              optional: false },
            { name: 'entry_id', optional: false,
              type: 'integer', control_type: 'integer',
              convert_input: 'integer_conversion',
              hint: 'The entry ID to delete' }
          ]
        end
      end
    },
    custom_action_input: {
      fields: lambda do |_connection, config_fields|
        verb = config_fields['verb']
        input_schema = parse_json(config_fields.dig('input', 'schema') || '[]')
        data_props =
          input_schema.map do |field|
            if config_fields['request_type'] == 'multipart' &&
               field['binary_content'] == 'true'
              field['type'] = 'object'
              field['properties'] = [
                { name: 'file_content', label: 'File contents', optional: false },
                {
                  name: 'content_type',
                  default: 'text/plain',
                  sticky: true
                },
                { name: 'original_filename', sticky: true }
              ]
            end
            field
          end
        data_props = call('make_schema_builder_fields_sticky', data_props)
        input_data =
          if input_schema.present?
            if input_schema.dig(0, 'type') == 'array' &&
               input_schema.dig(0, 'details', 'fake_array')
              {
                name: 'data',
                type: 'array',
                of: 'object',
                properties: data_props.dig(0, 'properties')
              }
            else
              { name: 'data', type: 'object', properties: data_props }
            end
          end

        [
          {
            name: 'path',
            hint: 'Base URI is <b>' \
                  'https://api.hibob.com/' \
                  '</b> - path will be appended to this URI. Use absolute URI to ' \
                  'override this base URI.',
            optional: false
          },
          if %w[post put patch].include?(verb)
            {
              name: 'request_type',
              default: 'json',
              sticky: true,
              extends_schema: true,
              control_type: 'select',
              pick_list: [
                ['JSON request body', 'json'],
                ['URL encoded form', 'url_encoded_form'],
                ['Mutipart form', 'multipart'],
                ['Raw request body', 'raw']
              ]
            }
          end,
          {
            name: 'response_type',
            default: 'json',
            sticky: false,
            extends_schema: true,
            control_type: 'select',
            pick_list: [['JSON response', 'json'], ['Raw response', 'raw']]
          },
          if %w[get options delete].include?(verb)
            {
              name: 'input',
              label: 'Request URL parameters',
              sticky: true,
              add_field_label: 'Add URL parameter',
              control_type: 'form-schema-builder',
              type: 'object',
              properties: [
                {
                  name: 'schema',
                  sticky: input_schema.blank?,
                  extends_schema: true
                },
                input_data
              ].compact
            }
          else
            {
              name: 'input',
              label: 'Request body parameters',
              sticky: true,
              type: 'object',
              properties:
                if config_fields['request_type'] == 'raw'
                  [{
                    name: 'data',
                    sticky: true,
                    control_type: 'text-area',
                    type: 'string'
                  }]
                else
                  [
                    {
                      name: 'schema',
                      sticky: input_schema.blank?,
                      extends_schema: true,
                      schema_neutral: true,
                      control_type: 'schema-designer',
                      sample_data_type: 'json_input',
                      custom_properties:
                        if config_fields['request_type'] == 'multipart'
                          [{
                            name: 'binary_content',
                            label: 'File attachment',
                            default: false,
                            optional: true,
                            sticky: true,
                            convert_input: 'boolean_conversion',
                            convert_output: 'boolean_conversion',
                            control_type: 'checkbox',
                            type: 'boolean'
                          }]
                        end
                    },
                    input_data
                  ].compact
                end
            }
          end,
          {
            name: 'request_headers',
            sticky: false,
            extends_schema: true,
            control_type: 'key_value',
            empty_list_title: 'Does this HTTP request require headers?',
            empty_list_text: 'Refer to the API documentation and add ' \
                             'required headers to this HTTP request',
            item_label: 'Header',
            type: 'array',
            of: 'object',
            properties: [{ name: 'key' }, { name: 'value' }]
          },
          unless config_fields['response_type'] == 'raw'
            {
              name: 'output',
              label: 'Response body',
              sticky: true,
              extends_schema: true,
              schema_neutral: true,
              control_type: 'schema-designer',
              sample_data_type: 'json_input'
            }
          end,
          {
            name: 'response_headers',
            sticky: false,
            extends_schema: true,
            schema_neutral: true,
            control_type: 'schema-designer',
            sample_data_type: 'json_input'
          }
        ].compact
      end
    },
    custom_action_output: {
      fields: lambda do |_connection, config_fields|
        response_body = { name: 'body' }

        [
          if config_fields['response_type'] == 'raw'
            response_body
          elsif (output = config_fields['output'])
            output_schema = call('format_schema', parse_json(output))
            if output_schema.dig(0, 'type') == 'array' &&
               output_schema.dig(0, 'details', 'fake_array')
              response_body[:type] = 'array'
              response_body[:properties] = output_schema.dig(0, 'properties')
            else
              response_body[:type] = 'object'
              response_body[:properties] = output_schema
            end

            response_body
          end,
          if (headers = config_fields['response_headers'])
            header_props = parse_json(headers)&.map do |field|
              if field[:name].present?
                field[:name] = field[:name].gsub(/\W/, '_').downcase
              elsif field['name'].present?
                field['name'] = field['name'].gsub(/\W/, '_').downcase
              end
              field
            end

            { name: 'headers', type: 'object', properties: header_props }
          end
        ].compact
      end
    },
    upload_document_input: {
      fields: lambda do |_conneciton, _config_fields|
        [
          { name: 'id', label: 'Employee ID',
            optional: false },
          { name: 'file', label: 'File content',
            optional: false,
            hint: 'The file to upload. File size should be less ' \
                  'than <b>1MB</b>' },
          { name: 'fileName', optional: false,
            hint: 'Provide the file name with extention if needed. ' \
                  'e.g. <b>image.jpg</b>' }
        ]
      end
    }
  },

  actions: {
    search_records: {
      title: 'Search records',
      subtitle: 'Retrieve a list of records, e.g. employees, that matches ' \
                'your search criteria',
      description: lambda do |_connection, search_object_list|
        "Search <span class='provider'>" \
          "#{search_object_list[:object] || 'records'}</span> " \
          'in <span class="provider">HiBob</span>'
      end,
      help: 'The Search records action returns results that match all your search ' \
            'criteria.',
      config_fields: [
        { name: 'object',
          optional: false,
          control_type: 'select',
          pick_list: :search_object_list,
          hint: "Select any HiBob object, e.g, <b>Employees</b>. If you're trying to " \
                'fetch fields from other objects not included in the selected object, ' \
                'make sure to add them to the <b>Fields to Retrieve</b> section. e.g, fetching ' \
                '<b>Base Salary</b> from <b>Employees</b>.' }
      ],
      input_fields: lambda do |object_definitions|
        object_definitions['search_records_input']
      end,
      execute: lambda do |_connection, input|
        response = if %w[employees_new employees].include?(input['object'])
                     input = input.except('filters') if input&.dig('filters', 0).blank?
                     input['fields'] = input['fields'].split(',') if input['fields'].present?

                     post("/v1/#{call('search_url', input)}").
                       payload(input.except('object')).
                       after_error_response(/.*/) do |code, body, header, message|
                       if code.to_i == 429
                         reset_time = header['x_ratelimit_reset']&.to_i
                         sleep_time = reset_time > 0 ? [reset_time - Time.now.to_i + 1, 1].max : 60
                         sleep(sleep_time)
                         nil
                       else
                         error("#{message}: #{body}")
                       end
                     end.
                       after_response do |_code, body, headers|
                       call('extract_rate_limit_headers', body, headers)
                     end
                   else
                     get("/v1/#{call('search_url', input)}", input.except('object', 'query_type')).
                       after_error_response(/.*/) do |code, body, header, message|
                       if code.to_i == 429
                         reset_time = header['x_ratelimit_reset']&.to_i
                         sleep_time = reset_time > 0 ? [reset_time - Time.now.to_i + 1, 1].max : 60
                         sleep(sleep_time)
                         nil
                       else
                         error("#{message}: #{body}")
                       end
                     end.
                       after_response do |_code, body, headers|
                       if input['object'] == 'company_list'
                         call('transform_company_lists', body, headers)
                       else
                         call('extract_rate_limit_headers', body, headers)
                       end
                     end
                   end

        response
      end,
      output_fields: lambda do |object_definitions|
        object_definitions['search_records_output']
      end,
      sample_output: lambda do |_connection, input|
        call('search_records_sample_output', input)
      end,

      retry_on_response: [429],

      retry_on_request: %w[GET POST],

      max_retries: 3
    },
    get_record: {
      title: 'Get record details',
      subtitle: 'Retrieves a specific record, e.g. <b>employee</b>',
      description: lambda do |_connection, get_object_list|
        "Get <span class='provider'>" \
          "#{get_object_list[:object] || 'record'}</span> " \
          'in <span class="provider">HiBob</span>'
      end,
      help: 'Retrieve the details of any standard or custom record, ' \
            'e.g. employee.',
      config_fields: [
        { name: 'object',
          optional: false,
          control_type: 'select',
          pick_list: :get_object_list,
          hint: 'Select any HiBob object, e.g. <b>employee</b>' }
      ],
      input_fields: lambda do |object_definitions|
        object_definitions['get_record_input']
      end,
      execute: lambda do |_connection, input|
        company_list_name = input['listName'] if input['object'].to_s == 'company_list'
        url = case input['object']
              when 'employee', 'employee_new'
                "people/#{input.delete('identifier')}"
              when 'company_list'
                "company/named-lists/#{input.delete('listName')}"
              when 'timeoff'
                "timeoff/employees/#{input.delete('id')}/requests" \
                "/#{input.delete('requestId')}"
              end

        if %w[employee employee_new].include?(input['object'])
          input['fields'] = input['fields'].split(',') if input['fields'].present?
          post("/v1/#{url}").
            payload(input.except('object')).
            after_error_response(/.*/) do |code, body, header, message|
              if code.to_i == 429
                reset_time = header['x_ratelimit_reset']&.to_i
                sleep_time = reset_time > 0 ? [reset_time - Time.now.to_i + 1, 1].max : 60
                sleep(sleep_time)
                nil
              else
                error("#{message}: #{body}")
              end
            end.
            after_response do |_code, body, headers|
            call('extract_rate_limit_headers', body, headers)
          end
        else
          get("/v1/#{url}", input.except('object')).
            after_error_response(/.*/) do |code, body, header, message|
              if code.to_i == 429
                reset_time = header['x_ratelimit_reset']&.to_i
                sleep_time = reset_time > 0 ? [reset_time - Time.now.to_i + 1, 1].max : 60
                sleep(sleep_time)
                nil
              else
                error("#{message}: #{body}")
              end
            end.
            after_response do |_code, body, headers|
            result = call('extract_rate_limit_headers', body, headers)
            if company_list_name.present? && result.is_a?(Hash)
              list_id = company_list_name.to_s
              display = (result['name'] || result[:name]).to_s.presence
              api_list_label = (result['label'] || result[:label]).to_s.presence
              display_title = display.present? && display != list_id ? display : nil
              values = result['values'] || result[:values] || []
              items = (result['items'] || result[:items]).presence || values
              labels = call('people_field_labels_by_list_key')
              list_name = display.presence || list_id
              list_label = api_list_label.presence ||
                           display_title.presence ||
                           labels[company_list_name].presence ||
                           list_id.labelize
              result = result.merge(
                'name' => list_name,
                'label' => list_label,
                'values' => values,
                'items' => items
              )
            end
            result
          end
        end
      end,
      output_fields: lambda do |object_definitions|
        object_definitions['get_record_output']
      end,
      sample_output: lambda do |_connection, input|
        call('get_record_sample_output', input)
      end,

      retry_on_response: [429],

      retry_on_request: %w[GET POST],

      max_retries: 3
    },
    update_record: {
      title: 'Update record',
      subtitle: 'Update any standard or custom record, e.g. employee, ' \
                'via its HiBob ID',
      description: lambda do |_connection, update_object_list|
        "Update <span class='provider'>" \
          "#{update_object_list[:object] || 'record'}</span> " \
          'in <span class="provider">HiBob</span>'
      end,
      help: 'Update any standard or custom record, e.g. employee, via its ' \
            'HiBob ID. First select the object, then specify the HiBob ID ' \
            'of the record to update',
      config_fields: [
        { name: 'object',
          optional: false,
          control_type: 'select',
          pick_list: :update_object_list,
          hint: 'Select any HiBob object, e.g. <b>employee</b>' }
      ],
      input_fields: lambda do |object_definitions|
        object_definitions['update_record_input']
      end,
      execute: lambda do |_connection, input|
        if input['object'] == 'employee'
          input = call('handle_multiselect_fields_new', input)
          input = call('convert_custom_field_types', input)
          input = call('convert_currency_format', input)
        end
        url = case input['object']
              when 'employee'
                "people/#{input.delete('id')}"
              when 'employee_email'
                "people/#{input.delete('id')}/email"
              when 'work_entry'
                "people/#{input.delete('employee_id')}/work/#{input.delete('entry_id')}"
              when 'company_list_item'
                "company/named-lists/#{input.delete('listName')}/#{input.delete('itemId')}"
              end
        put("/v1/#{url}", input.except('object')).
          after_error_response(/.*/) do |code, body, header, message|
            if code.to_i == 429
              reset_time = header['x_ratelimit_reset']&.to_i
              sleep_time = reset_time > 0 ? [reset_time - Time.now.to_i + 1, 1].max : 60
              sleep(sleep_time)
              nil
            else
              error("#{message}: #{body}")
            end
          end.
          after_response do |_code, body, headers|
            call('extract_rate_limit_headers', body, headers)
          end
      end,
      output_fields: lambda do |object_definitions|
        object_definitions['update_record_output']
      end,
      sample_output: lambda do |_connection, _input|
        call('rate_limit_sample_output')
      end,

      retry_on_response: [429],

      retry_on_request: ['PUT'],

      max_retries: 3
    },
    create_record: {
      title: 'Create record',
      subtitle: 'Create any standard or custom record, e.g. employee, ' \
                'in HiBob.',
      description: lambda do |_connection, create_object_list|
        "Create <span class='provider'>" \
          "#{create_object_list[:object] || 'record'}</span> " \
          'in <span class="provider">HiBob</span>'
      end,
      help: 'Create any standard or custom record, e.g. employee, in HiBob.',
      config_fields: [
        { name: 'object',
          optional: false,
          control_type: 'select',
          pick_list: :create_object_list,
          hint: 'Select any HiBob object, e.g. <b>employee</b>' }
      ],
      input_fields: lambda do |object_definitions|
        object_definitions['create_record_input']
      end,
      execute: lambda do |_connection, input|
        url = case input['object']
              when 'work_entry'
                "people/#{input.delete('employee_id')}/work"
              when 'employment_entry'
                "people/#{input.delete('employee_id')}/employment"
              when 'salary_entry'
                "people/#{input.delete('employee_id')}/salaries"
              when 'variable_payment'
                "people/#{input.delete('employee_id')}/variable"
              when 'employee_equity_grant'
                "people/#{input.delete('employee_id')}/equities"
              when 'training_record'
                "people/#{input.delete('employee_id')}/training"
              when 'company_list_item'
                "company/named-lists/#{input.delete('listName')}"
              when 'timeoff_request'
                "timeoff/employees/#{input.delete('id')}/requests"
              end
        post("/v1/#{url}", input.except('object')).
          after_error_response(/.*/) do |code, body, header, message|
            if code.to_i == 429
              reset_time = header['x_ratelimit_reset']&.to_i
              sleep_time = reset_time > 0 ? [reset_time - Time.now.to_i + 1, 1].max : 60
              sleep(sleep_time)
              nil
            else
              error("#{message}: #{body}")
            end
          end.
          after_response do |_code, body, headers|
            call('extract_rate_limit_headers', body, headers)
          end
      end,
      output_fields: lambda do |object_definitions|
        object_definitions['create_record_output']
      end,
      sample_output: lambda do |_connection, _input|
        { 'id' => '123xxx' }.merge(call('rate_limit_sample_output'))
      end,

      retry_on_response: [429],

      retry_on_request: ['POST'],

      max_retries: 3
    },
    delete_record: {
      title: 'Delete record',
      subtitle: 'Delete any standard or custom record, e.g. employee, ' \
                'via its HiBob ID',
      description: lambda do |_connection, delete_object_list|
        "Delete <span class='provider'>" \
          "#{delete_object_list[:object] || 'record'}</span> " \
          'in <span class="provider">HiBob</span>'
      end,
      help: 'Delete any standard or custom record, e.g. employee, via its ' \
            'HiBob ID. First select the object, then specify the HiBob ID ' \
            'of the record to delete',
      config_fields: [
        { name: 'object',
          optional: false,
          control_type: 'select',
          pick_list: :delete_object_list,
          hint: 'Select any HiBob object, e.g. <b>employee</b>' }
      ],
      input_fields: lambda do |object_definitions|
        object_definitions['delete_record_input']
      end,
      execute: lambda do |_connection, input|
        url = case input['object']
              when 'work_entry'
                "people/#{input['id']}/work/#{input['entry_id']}"
              when 'employment_entry'
                "people/#{input['id']}/employment/#{input['entry_id']}"
              when 'salary_entry'
                "people/#{input['id']}/salaries/#{input['entry_id']}"
              when 'employee_equity_grant'
                "people/#{input['id']}/equities/#{input['entry_id']}"
              when 'timeoff_request'
                "timeoff/employees/#{input['id']}/requests/#{input['requestId']}"
              when 'company_list_item'
                "company/named-lists/#{input['listName']}/#{input['itemId']}"
              when 'document'
                "docs/people/#{input['id']}/#{input['folder_type']}" \
                "/#{input['docId']}"
              when 'variable_payment'
                "people/#{input['id']}/variable/#{input['entry_id']}"
              when 'training_record'
                "people/#{input['id']}/training/#{input['entry_id']}"
              end
        delete("/v1/#{url}").
          after_error_response(/.*/) do |code, body, header, message|
            if code.to_i == 429
              reset_time = header['x_ratelimit_reset']&.to_i
              sleep_time = reset_time > 0 ? [reset_time - Time.now.to_i + 1, 1].max : 60
              sleep(sleep_time)
              nil
            else
              error("#{message}: #{body}")
            end
          end.
          after_response do |_code, body, headers|
            call('extract_rate_limit_headers', body, headers)
          end
      end,
      output_fields: lambda do |object_definitions|
        object_definitions['delete_record_output']
      end,
      sample_output: lambda do |_connection, _input|
        call('rate_limit_sample_output')
      end,

      retry_on_response: [429],

      retry_on_request: ['DELETE'],

      max_retries: 3
    },
    download_report: {
      title: 'Download report',
      subtitle: 'Download report in HiBob',
      description: lambda do |_connection|
        "Download <span class='provider'>Report</span> " \
          'in <span class="provider">HiBob</span>'
      end,
      help: 'Downloads report data file of the specified format.',
      input_fields: lambda do |object_definition|
        object_definition['download_report_input']
      end,
      execute: lambda do |_connection, input|
        response = get("/v1/company/reports/#{input.delete('reportId')}/download", input).
                   response_format_raw.
                   after_error_response(/.*/) do |code, body, header, message|
                     if code.to_i == 429
                       reset_time = header['x_ratelimit_reset']&.to_i
                       sleep_time = reset_time > 0 ? [reset_time - Time.now.to_i + 1, 1].max : 60
                       sleep(sleep_time)
                       nil
                     else
                       error("#{message}: #{body}")
                     end
                   end.
                   after_response do |_code, body, headers|
          {
            file_content: body,
            x_ratelimit_limit: headers['x_ratelimit_limit'],
            x_ratelimit_remaining: headers['x_ratelimit_remaining'],
            x_ratelimit_reset: headers['x_ratelimit_reset']
          }
        end

        response
      end,
      output_fields: lambda do |object_definitions|
        object_definitions['download_report_output']
      end,
      summarize_output: ['file_content'],
      sample_output: lambda do |_connection, _input|
        { 'file_content' => '123xxxxxabxyz' }.merge(call('rate_limit_sample_output'))
      end,

      retry_on_response: [429],

      retry_on_request: ['GET'],

      max_retries: 3
    },
    download_report_async: {
      title: 'Download report (Async)',
      subtitle: 'Download report in HiBob',
      description: lambda do |_connection|
        "Download <span class='provider'>Report (Async)</span> " \
          'in <span class="provider">HiBob</span>'
      end,
      help: "Downloads report data file when it's ready.",
      input_fields: lambda do |object_definition|
        object_definition['download_report_input']
      end,
      execute: lambda do |_connection, input, _eis, _eos, continue|
        step_time = 60
        if continue.blank?
          response = get("/v1/company/reports/#{input.delete('reportId')}/download-async", input).
                     after_response do |_code, _body, headers|
                       headers['location']
                     end.after_error_response(/.*/) do |_code, body, _header, message|
                       error("#{message}: #{body}")
                     end

          error('Report generation failed: Location header not returned.') if response.blank?

          reinvoke_after(seconds: step_time,
                         continue: { url: response })
        elsif continue[:url].present?
          response = get(continue[:url]).response_format_raw.
                     after_response do |code, body, _headers|
                       {
                         status_code: code,
                         body: body
                       }
                     end.
                     after_error_response(/.*/) do |_code, body, _header, message|
                       error("#{message}: #{body}")
                     end || {}

          if response[:status_code] == 200
            { file_content: response[:body] }
          else
            reinvoke_after(seconds: step_time,
                           continue: { url: continue[:url] })
          end
        else
          { completed: false,
            error: 'Invalid download URL or File not found' }
        end
      end,
      output_fields: lambda do |_object_definition|
        [
          { name: 'file_content', label: 'File contents' }
        ]
      end,
      summarize_output: ['file_content'],
      sample_output: lambda do
        {
          file_content: '123xxxxxabxyz'
        }
      end
    },
    upload_document: {
      title: 'Upload document',
      subtitle: 'Upload document in HiBob',
      description: lambda do |_connection|
        "Upload <span class='provider'>Document</span> " \
          'in <span class="provider">HiBob</span>'
      end,
      help: 'Upload document to the specific folder in HiBob. The maximum ' \
            'file size allowed to upload is 1MB.',
      config_fields: [
        { name: 'document_location', optional: false,
          control_type: 'select',
          pick_list: %w[shared confidential].map { |e| [e.labelize, e] } }
      ],
      input_fields: lambda do |object_definition|
        object_definition['upload_document_input']
      end,
      execute: lambda do |_connection, input|
        post("/v1/docs/people/#{input.delete('id')}/" \
             "#{input.delete('document_location')}/upload").
          payload({ file: [input['file'], 'application/octet-stream', input['fileName']] }).
          request_format_multipart_form.
          after_error_response(/.*/) do |code, body, header, message|
            if code.to_i == 429
              reset_time = header['x_ratelimit_reset']&.to_i
              sleep_time = reset_time > 0 ? [reset_time - Time.now.to_i + 1, 1].max : 60
              sleep(sleep_time)
              nil
            else
              error("#{message}: #{body}")
            end
          end.
          after_response do |_code, body, headers|
          call('extract_rate_limit_headers', body, headers)
        end
      end,
      output_fields: lambda do |object_definitions|
        object_definitions['upload_document_output']
      end,
      sample_output: lambda do |_connection, _input|
        { 'id' => '123xxx' }.merge(call('rate_limit_sample_output'))
      end,

      retry_on_response: [429],

      retry_on_request: ['POST'],

      max_retries: 3
    },
    revoke_access: {
      title: 'Revoke access for employee',
      subtitle: 'Revoke access to HiBob for employee',
      description: "Revoke <span class='provider'>Access for employee</span> " \
                   'in <span class="provider">HiBob</span>',
      input_fields: lambda do |_object_definition|
        [
          { name: 'identifier', label: 'Employee ID',
            optional: false }
        ]
      end,
      execute: lambda do |_conneciton, input|
        post("/v1/employees/#{input['identifier']}/uninvite").
          after_error_response(/.*/) do |code, body, header, message|
            if code.to_i == 429
              reset_time = header['x_ratelimit_reset']&.to_i
              sleep_time = reset_time > 0 ? [reset_time - Time.now.to_i + 1, 1].max : 60
              sleep(sleep_time)
              nil
            else
              error("#{message}: #{body}")
            end
          end.
          after_response do |_code, body, headers|
            call('extract_rate_limit_headers', body, headers)
          end
      end,
      output_fields: lambda do |object_definitions|
        object_definitions['revoke_access_output']
      end,

      sample_output: lambda do |_connection, _input|
        call('rate_limit_sample_output')
      end,

      retry_on_response: [429],

      retry_on_request: ['POST'],

      max_retries: 3
    },
    invite_employee: {
      title: 'Invite an employee',
      subtitle: 'Invite an employee with a welcome wizard ID',
      description: "Invite an <span class='provider'>employee</span> " \
                   'in <span class="provider">HiBob</span>',
      input_fields: lambda do |_object_definition|
        [
          { name: 'employeeId', label: 'Employee ID',
            optional: false },
          { name: 'welcomeWizardId', optional: false,
            type: 'integer', control_type: 'integer',
            convert_input: 'integer_conversion' }
        ]
      end,
      execute: lambda do |_conneciton, input|
        post("/v1/employees/#{input.delete('employeeId')}/invitations", input).
          after_error_response(/.*/) do |code, body, header, message|
            if code.to_i == 429
              reset_time = header['x_ratelimit_reset']&.to_i
              sleep_time = reset_time > 0 ? [reset_time - Time.now.to_i + 1, 1].max : 60
              sleep(sleep_time)
              nil
            else
              error("#{message}: #{body}")
            end
          end.
          after_response do |_code, body, headers|
            call('extract_rate_limit_headers', body, headers)
          end
      end,
      output_fields: lambda do |object_definitions|
        object_definitions['invite_employee_output']
      end,

      sample_output: lambda do |_connection, _input|
        call('rate_limit_sample_output')
      end,

      retry_on_response: [429],

      retry_on_request: ['POST'],

      max_retries: 3
    },
    make_task_complete: {
      title: 'Make a task complete',
      subtitle: 'Make a task complete in HiBob',
      description: "Make a <span class='provider'>task complete</span> " \
                   'in <span class="provider">HiBob</span>',
      input_fields: lambda do |_object_definition|
        [
          { name: 'taskId', optional: false }
        ]
      end,
      execute: lambda do |_conneciton, input|
        post("/v1/tasks/#{input['taskId']}/complete").
          after_error_response(/.*/) do |code, body, header, message|
            if code.to_i == 429
              reset_time = header['x_ratelimit_reset']&.to_i
              sleep_time = reset_time > 0 ? [reset_time - Time.now.to_i + 1, 1].max : 60
              sleep(sleep_time)
              nil
            else
              error("#{message}: #{body}")
            end
          end.
          after_response do |_code, body, headers|
            call('extract_rate_limit_headers', body, headers)
          end
      end,
      output_fields: lambda do |object_definitions|
        object_definitions['make_task_complete_output']
      end,
      sample_output: lambda do |_connection, _input|
        { 'toDosUpdated' => 1 }.merge(call('rate_limit_sample_output'))
      end,

      retry_on_response: [429],

      retry_on_request: ['POST'],

      max_retries: 3
    },
    custom_action: {
      subtitle: 'Build your own HiBob action with a HTTP request',

      description: lambda do |object_value, _object_label|
        "<span class='provider'>" \
          "#{object_value[:action_name] || 'Custom action'}</span> in " \
          "<span class='provider'>HiBob</span>"
      end,

      help: {
        body: 'Build your own HiBob action with a HTTP request. ' \
              'The request will be authorized with your HiBob connection.',
        learn_more_url: 'https://apidocs.hibob.com/reference',
        learn_more_text: 'HiBob API documentation'
      },

      config_fields: [
        {
          name: 'action_name',
          hint: "Give this action you're building a descriptive name, e.g. " \
                'create record, get record',
          default: 'Custom action',
          optional: false,
          schema_neutral: true
        },
        {
          name: 'verb',
          label: 'Method',
          hint: 'Select HTTP method of the request',
          optional: false,
          control_type: 'select',
          pick_list: %w[get post put patch options delete].map { |verb| [verb.upcase, verb] }
        }
      ],

      input_fields: lambda do |object_definition|
        object_definition['custom_action_input']
      end,

      execute: lambda do |_connection, input|
        verb = input['verb']
        if %w[get post put patch options delete].exclude?(verb)
          error("#{verb.upcase} not supported")
        end
        path = input['path']
        data = input.dig('input', 'data') || {}
        if input['request_type'] == 'multipart'
          data = data.each_with_object({}) do |(key, val), hash|
            hash[key] = if val.is_a?(Hash)
                          [val[:file_content], val[:content_type], val[:original_filename]]
                        else
                          val
                        end
          end
        end
        request_headers = input['request_headers']&.
                          each_with_object({}) do |item, hash|
          hash[item['key']] = item['value']
        end || {}
        request = case verb
                  when 'get'
                    get(path, data)
                  when 'post'
                    if input['request_type'] == 'raw'
                      post(path).request_body(data)
                    else
                      post(path, data)
                    end
                  when 'put'
                    if input['request_type'] == 'raw'
                      put(path).request_body(data)
                    else
                      put(path, data)
                    end
                  when 'patch'
                    if input['request_type'] == 'raw'
                      patch(path).request_body(data)
                    else
                      patch(path, data)
                    end
                  when 'options'
                    options(path, data)
                  when 'delete'
                    delete(path, data)
                  end.case_sensitive_headers(request_headers)
        request = case input['request_type']
                  when 'url_encoded_form'
                    request.request_format_www_form_urlencoded
                  when 'multipart'
                    request.request_format_multipart_form
                  else
                    request
                  end
        response =
          if input['response_type'] == 'raw'
            request.response_format_raw
          else
            request
          end.
          after_error_response(/.*/) do |code, body, headers, message|
            error({ code: code, message: message, body: body, headers: headers }.
              to_json)
          end

        response.after_response do |_code, res_body, res_headers|
          {
            body: res_body ? call('format_response', res_body) : nil,
            headers: res_headers
          }
        end
      end,

      output_fields: lambda do |object_definition|
        object_definition['custom_action_output']
      end
    }
  },

  webhook_keys: lambda do |_params, _headers, payload|
    "#{payload['type']}@#{payload['companyId']}"
  end,

  triggers: {
    new_event: {
      title: 'New event',
      subtitle: 'Monitor a new event in HiBob. <b>e.g. Employee created.</b>',
      deprecated: true,
      description: lambda do |_connection, input|
        event = input['event_type'].present? ? "(#{input['event_type']})" : ''
        "New event <span class='provider'>" \
          "#{event} </span> in <span class='provider'>HiBob</span>"
      end,
      help: lambda do |_input, picklist_label, connection, webhook_base_url|
        help_text = if picklist_label['event_type'] == 'Task list assigned'
                      'Triggers immediately as soon as task list assigned. '
                    elsif picklist_label['event_type'] == 'Task status updated'
                      'Triggers immediately as soon as task status changed. '
                    elsif picklist_label['event'] == 'Document'
                      'Triggers immediately after signing process is completed. ' \
                        'If request has two signers and only one has signed the message ' \
                        "won't be send until the second signer completes signing. "
                    else
                      'Triggers immediately as soon as trigger events, e.g. ' \
                        'employee created, occurs. '
                    end
        "#{help_text}<br>The static webhook URI is " \
          "<b class=\"tips__highlight\">#{webhook_base_url}" \
          '</b><br><b>An employee has to be created prior to using this trigger. ' \
          'If an employee was created only after establishing the connection, reconnect.</b><br>' \
          "<b>Reconnect required: #{!connection['companyId'].present?}</b>"
      end,
      config_fields: [
        { name: 'event', label: 'Object',
          optional: false,
          control_type: 'select',
          change_on_blur: true,
          hint: 'Select any standard HiBob object.',
          pick_list: 'event_trigger_list' },
        { name: 'event_type',
          label: 'Event type',
          optional: false,
          change_on_blur: true,
          ngIf: 'input.event',
          control_type: 'select',
          hint: 'Select a specific event type.',
          pick_list: 'event_type_trigger_list',
          pick_list_params: { event: 'event' } }
      ],
      webhook_key: lambda do |connection, input|
        "#{input['event_type']}@#{connection['companyId']}"
      end,
      webhook_notification: lambda do |_input, payload|
        payload
      end,
      dedup: lambda do |_event|
        Time.now.to_f
      end,
      output_fields: lambda do |object_definitions|
        object_definitions['webhook_output_schema']
      end
    },
    new_event_trigger_v2: {
      title: 'New event',
      subtitle: 'Monitor a new event in HiBob. <b>e.g. Employee created.</b>',
      description: lambda do |_connection, input|
        event = input['event_type'].present? ? "(#{input['event_type']})" : ''
        "New event <span class='provider'>" \
          "#{event} </span> in <span class='provider'>HiBob</span>"
      end,
      help: lambda do |_input, picklist_label, connection, webhook_base_url|
        help_text = if picklist_label['event_type'] == 'Task list assigned'
                      'Triggers immediately as soon as task list assigned. '
                    elsif picklist_label['event_type'] == 'Task status updated'
                      'Triggers immediately as soon as task status changed. '
                    elsif picklist_label['event'] == 'Document'
                      'Triggers immediately after signing process is completed. ' \
                        'If request has two signers and only one has signed the message ' \
                        "won't be send until the second signer completes signing. "
                    else
                      'Triggers immediately as soon as trigger events, e.g. ' \
                        'employee created, occurs. '
                    end
        "#{help_text} <br>The static webhook URI is <b><a>#{webhook_base_url}</a></b><br>" \
          '<b>An employee has to be created prior to using this trigger. If an employee was ' \
          'created only after establishing the connection, reconnect.</b><br>' \
          "<b>Reconnect required: #{!connection['companyId'].present?}</b>"
      end,
      config_fields: [
        { name: 'event', label: 'Object',
          optional: false,
          control_type: 'select',
          change_on_blur: true,
          hint: 'Select any standard HiBob object.',
          pick_list: 'event_v2_trigger_list' },
        { name: 'event_type',
          label: 'Event type',
          optional: false,
          change_on_blur: true,
          ngIf: 'input.event',
          control_type: 'select',
          hint: 'Select a specific event type.',
          pick_list: 'event_type_v2_trigger_list',
          pick_list_params: { event: 'event' } }
      ],
      webhook_key: lambda do |connection, input|
        "#{input['event_type']}@#{connection['companyId']}"
      end,
      webhook_notification: lambda do |_input, payload|
        payload
      end,
      dedup: lambda do |event|
        "#{event['type']}@#{Time.now.to_f}"
      end,
      output_fields: lambda do |object_definitions|
        object_definitions['webhook_v2_output_schema']
      end,
      sample_output: lambda do |_connection, input|
        next {} unless input['event_type'].present?

        call('sample_webhook_output', input['event'], input['event_type'])
      end
    },
    new_or_updated_time_off_request: {
      title: 'New/updated time off request',
      subtitle: 'Triggers when a time off request is created/updated in HiBob.',
      description: lambda do |_connection, _input|
                     "New or updated <span class='provider'>" \
                       "time off request</span> in <span class='provider'>HiBob</span>"
                   end,
      help: 'Triggers when a time off request is created or updated',

      input_fields: lambda do
        [
          {
            name: 'since',
            label: 'When first started, this recipe should pick up events from',
            type: 'timestamp',
            optional: true,
            sticky: true,
            hint: 'When you start recipe for the first time, it picks up ' \
                  'trigger events from this specified date and time. Defaults to ' \
                  'the current time.'
          },
          {
            name: 'includePending',
            type: 'boolean',
            control_type: 'checkbox',
            sticky: 'true',
            optional: 'true',
            hint: 'Indicates whether to include pending ' \
                  'requests in the results. If left blank, defaults to true',
            convert_input: 'boolean_conversion',
            convert_output: 'boolean_conversion',
            toggle_hint: 'Select from list',
            toggle_field: {
              name: 'includePending',
              label: 'Include pending',
              type: 'string',
              control_type: 'text',
              optional: 'true',
              convert_input: 'boolean_conversion',
              convert_output: 'boolean_conversion',
              hint: 'Allowed values are true or false',
              toggle_hint: 'Use custom value'
            }
          }
        ]
      end,

      poll: lambda do |_connection, input, closure|
        closure = {} unless closure.present?
        updated_since = (closure['cursor'] ||
          input['since'] || 1.hour.ago).to_time.utc.iso8601

        time_off_reqs = get('/v1/timeoff/requests/changes').
                        params(since: updated_since,
                               includePending: input['includePending'] || 'true')

        closure['cursor'] = Time.now.to_time.utc.iso8601

        {
          events: time_off_reqs['changes'],
          next_poll: closure,
          can_poll_more: false
        }
      end,

      dedup: lambda do |event|
        "#{event['employeeId']}@#{event['changeType']}@#{event['requestId']}"
      end,

      output_fields: lambda do |object_definitions|
        object_definitions['time_off_request_output']
      end,

      sample_output: lambda do |_connection, _input|
        {
          totalDuration: 32,
          policyTypeDisplayName: 'Holiday',
          changeReason: '',
          endDate: '2024-11-21',
          changeType: 'Created',
          employeeEmail: 'johndoe@example.com',
          employeeId: '3277244805502993077',
          type: 'days',
          requestId: 24_138_915,
          startPortion: 'all_day',
          employeeDisplayName: 'John Doe',
          durationUnit: 'days',
          endPortion: 'all_day',
          totalCost: 22,
          startDate: '2024-10-21'
        }
      end
    }
  },

  pick_lists: {
    event_v2_trigger_list: lambda do
      %w[employee time_off task document workforce_planning].map { |e| [e.labelize, e] }
    end,
    event_trigger_list: lambda do
      %w[employee task document].map { |e| [e.labelize, e] }
    end,
    event_type_v2_trigger_list: lambda do |_connection, event:|
      case event
      when 'employee'
        [
          ['Employee created', 'employee.created'],
          ['Employee updated', 'employee.updated'],
          ['Employee deleted', 'employee.deleted'],
          ['Employee left/terminated', 'employee.left'],
          ['Employee joined', 'employee.joined'],
          ['Employee activated', 'employee.activated'],
          ['Employee inactivated', 'employee.inactivated'],
          ['Employee temporary leave', 'employee.temporaryLeave'],
          ['Employee table entry created', 'table.entry.created'],
          ['Employee table entry updated', 'table.entry.updated']
        ]
      when 'task'
        [
          ['Task list assigned', 'todo.assign'],
          ['Task status updated', 'todo.changedStatus']
        ]
      when 'document'
        [
          ['Documents E-sign completed', 'documents.eSign.completed']
        ]
      when 'time_off'
        [
          ['Time off request created', 'timeoff.request.requested'],
          ['Time off request approved', 'timeoff.request.approved'],
          ['Time off request declined', 'timeoff.request.declined'],
          ['Time off request cancelled', 'timeoff.request.cancelled'],
          ['Time off request deleted', 'timeoff.request.deleted'],
          ['Time off request updated', 'timeoff.request.updated'],
          ['Time off request created from import', 'timeoff.request.imported']
        ]
      when 'workforce_planning'
        [
          ['Workforce planning position created', 'workforcePlanning.position.created'],
          ['Workforce planning position updated', 'workforcePlanning.position.updated'],
          ['Workforce planning position opening created',
           'workforcePlanning.positionOpening.created'],
          ['Workforce planning position opening updated',
           'workforcePlanning.positionOpening.updated'],
          ['Workforce planning position opening deleted',
           'workforcePlanning.positionOpening.deleted'],
          ['Workforce planning position budget created',
           'workforcePlanning.positionBudget.created'],
          ['Workforce planning position budget updated',
           'workforcePlanning.positionBudget.updated']
        ]
      end
    end,
    event_type_trigger_list: lambda do |_connection, event:|
      case event
      when 'employee'
        [
          ['Employee created', 'employee.created'],
          ['Employee updated', 'employee.updated'],
          ['Employee deleted', 'employee.deleted'],
          ['Employee left', 'employee.left'],
          ['Employee joined', 'employee.joined'],
          ['Employee activated', 'employee.activated'],
          ['Employee inactivated', 'employee.inactivated']
        ]
      when 'task'
        [
          ['Task list assigned', 'todo.assign'],
          ['Task status updated', 'todo.changedStatus']
        ]
      when 'document'
        [
          ['Documents E-sign completed', 'documents.eSign.completed']
        ]
      end
    end,
    search_object_list: lambda do
      [
        ['Employees [Deprecated]', 'employees'],
        %w[Employees employees_new],
        ["Employee's work history", 'employee_work_history'],
        ["Employee's employment history", 'employee_employment_history'],
        ["Employee's life-cycle status history", 'employee_life_cycle_history'],
        ["Employee's salary history", 'employee_salary_history'],
        ['Company lists', 'company_list'],
        ['Company reports', 'company_report'],
        ['Company fields', 'company_field'],
        ['Onboarding wizards', 'onboarding_wizard'],
        %w[Tasks task],
        %w[Timeoff timeoff]
      ]
    end,
    get_object_list: lambda do
      [
        ['Employee [Deprecated]', 'employee'],
        %w[Employee employee_new],
        ['Company list', 'company_list'],
        %w[Timeoff timeoff]
      ]
    end,
    create_object_list: lambda do
      [
        ["Employee's work entry", 'work_entry'],
        ["Employee's employment entry", 'employment_entry'],
        ["Employee's salary entry", 'salary_entry'],
        ["Employee's variable payment", 'variable_payment'],
        ["Employee's training record", 'training_record'],
        ['Company list item', 'company_list_item'],
        ['Timeoff request', 'timeoff_request'],
        ["Employee's equity grant", 'employee_equity_grant']
      ]
    end,
    update_object_list: lambda do
      %w[employee_email work_entry company_list_item employee].map { |e| [e.labelize, e] }
    end,
    delete_object_list: lambda do
      [
        ["Employee's work entry", 'work_entry'],
        ["Employee's employment entry", 'employment_entry'],
        ["Employee's salary entry", 'salary_entry'],
        ["Employee's Equity grant", 'employee_equity_grant'],
        ["Employee's variable payment", 'variable_payment'],
        ["Employee's training record", 'training_record'],
        ['Company list item', 'company_list_item'],
        ['Timeoff request', 'timeoff_request'],
        %w[Document document]
      ]
    end,
    pay_period_list: lambda do
      %w[Annual Hourly Daily Weekly Monthly].map { |e| [e, e] }
    end,
    payment_period_list: lambda do
      %w[Annual Half-Yearly Quarterly Monthly].map { |e| [e, e] }
    end,
    pay_frequency_list: lambda do
      ['Weekly', 'Monthly', 'Pro rata', 'Every two weeks', 'Twice a month',
       'Four weekly'].map do |e|
        [e, e]
      end
    end,
    timeoff_portion_list: lambda do
      %w[all_day morning afternoon].map { |e| [e.labelize, e] }
    end,
    timeoff_request_range_list: lambda do
      %w[hours days].map { |e| [e.labelize, e] }
    end,
    timeoff_policy_list: lambda do
      %w[Holiday Sick].map { |e| [e.labelize, e] }
    end,
    grant_type_list: lambda do
      ['Initial Grant', 'Merit Grant'].map { |e| [e.labelize, e] }
    end,
    grant_status_list: lambda do
      ['Granted', 'Pending Approval'].map { |e| [e, e] }
    end,
    fields_to_retrieve: lambda do
      get('v1/company/people/fields')&.
        pluck('name', 'id')
    end
  },

  methods: {

    extract_rate_limit_headers: lambda do |body, headers|
      rate_limit_headers = {
        x_ratelimit_limit: headers['x_ratelimit_limit'],
        x_ratelimit_remaining: headers['x_ratelimit_remaining'],
        x_ratelimit_reset: headers['x_ratelimit_reset']
      }

      if body.is_a?(Array)
        { 'values' => body }.merge(rate_limit_headers)
      else
        body.merge(rate_limit_headers)
      end
    end,

    hibob_unwrap_response_json: lambda do |data|
      if data.is_a?(Hash)
        body = data['body'] if data.has_key?('body') && !data['body'].nil?
        body = data[:body] if body.nil? && data.has_key?(:body) && !data[:body].nil?
        return body unless body.nil?
      end
      data
    end,
    hibob_parse_api_response: lambda do |data|
      data = data.response! if data.respond_to?(:response!)

      unwrapped = call('hibob_unwrap_response_json', data)
      if unwrapped.is_a?(String)
        return {} if unwrapped.blank?

        parse_json(unwrapped)
      elsif unwrapped.is_a?(Hash) || unwrapped.is_a?(Array)
        unwrapped
      else
        {}
      end
    end,
    add_hash_field_label: lambda do |f, h|
      return h unless f.is_a?(Hash)

      n = (f['name'] || f[:name]).to_s.strip
      return h if n.blank?

      lid = f.dig('typeData', 'listId')
      h[lid.to_s] = n if lid.present?
      jp = (f['jsonPath'] || f[:jsonPath]).to_s
      if jp.present?
        h[jp] = n
        h[jp.split('.').last] = n if jp.include?('.')
      end
      eid = f['id'] || f[:id]
      h[eid.to_s] = n if eid.present?
      h
    end,
    add_custom_table_composite_list_labels: lambda do |meta, h|
      return h unless meta.is_a?(Hash)

      (meta['tables'] || meta[:tables] || []).each do |tbl|
        next unless tbl.is_a?(Hash)

        tid = (tbl['id'] || tbl[:id]).to_s
        next if tid.blank?

        (tbl['columns'] || tbl[:columns] || []).each do |col|
          next unless col.is_a?(Hash)

          n = (col['name'] || col[:name]).to_s.strip
          next if n.blank?

          cid = (col['id'] || col[:id]).to_s
          h["#{tid}.#{cid}"] = n if cid.present?
        end
      end
      h
    end,
    add_list_labels_from_tree: lambda do |node, h|
      case node
      when Array
        node.each { |n| call('add_list_labels_from_tree', n, h) }
      when Hash
        call('add_hash_field_label', node, h)
        node.each_value do |v|
          call('add_list_labels_from_tree', v, h) if v.is_a?(Array) || v.is_a?(Hash)
        end
      end
      h
    end,
    people_field_labels_by_list_key: lambda do
      h = {}
      people_raw =
        get('/v1/company/people/fields').
        after_error_response(/.*/) do |code, body, header, message|
          if code.to_i == 429
            reset_time = header['x_ratelimit_reset']&.to_i
            sleep_time = reset_time > 0 ? [reset_time - Time.now.to_i + 1, 1].max : 60
            sleep(sleep_time)
            nil
          else
            error("#{message}: #{body}")
          end
        end
      fields = call('hibob_parse_api_response', people_raw)
      fields = [] unless fields.is_a?(Array)
      fields.each { |f| call('add_hash_field_label', f, h) }
      meta_raw =
        get('/v1/people/custom-tables/metadata').
        after_error_response(/.*/) do |code, body, header, message|
          if code.to_i == 429
            reset_time = header['x_ratelimit_reset']&.to_i
            sleep_time = reset_time > 0 ? [reset_time - Time.now.to_i + 1, 1].max : 60
            sleep(sleep_time)
            nil
          else
            error("#{message}: #{body}")
          end
        end
      meta = call('hibob_parse_api_response', meta_raw)
      call('add_list_labels_from_tree', meta, h) if meta.present?
      call('add_custom_table_composite_list_labels', meta, h) if meta.is_a?(Hash)
      h
    end,

    transform_company_lists: lambda do |body, headers|
      columns =
        if body.is_a?(Hash)
          nested = body['company_lists'] || body[:company_lists]
          nested.is_a?(Hash) ? nested : body
        else
          {}
        end

      labels = call('people_field_labels_by_list_key')

      merged = {}
      company_lists = []

      columns.each do |list_name, list_data|
        next unless list_data.is_a?(Hash)

        key = list_name.to_s
        display_name = (list_data['name'] || list_data[:name]).to_s.presence
        api_list_label = (list_data['label'] || list_data[:label]).to_s.presence
        display_title = display_name.present? && display_name != key ? display_name : nil
        list_name = display_name.presence || key
        list_label = api_list_label.presence ||
                     display_title.presence ||
                     labels[key].presence ||
                     key.labelize
        values = list_data['values'] || list_data[:values] || []
        items = (list_data['items'] || list_data[:items]).presence || values

        payload = {
          'name' => list_name,
          'label' => list_label,
          'values' => values,
          'items' => items
        }

        merged[key] = payload
        company_lists << payload
      end

      transformed_body = merged.merge('company_lists' => company_lists)
      call('extract_rate_limit_headers', transformed_body, headers)
    end,

    company_list_item_schema: lambda do
      [
        { name: 'id', type: 'integer' },
        { name: 'value' },
        { name: 'name' },
        { name: 'archived', type: 'boolean' },
        { name: 'children',
          type: 'array', of: 'object',
          properties: [
            { name: 'id', type: 'integer' },
            { name: 'value' },
            { name: 'name' },
            { name: 'archived', type: 'boolean' },
            { name: 'children' }
          ] }
      ]
    end,

    add_rate_limit_fields: lambda do |base_fields|
      base_fields.push(
        { name: 'x_ratelimit_limit', label: 'Rate limit', type: 'integer' },
        { name: 'x_ratelimit_remaining', label: 'Requests remaining',
          type: 'integer' },
        { name: 'x_ratelimit_reset', label: 'Rate limit reset time',
          type: 'integer' }
      )
    end,

    get_record_sample_output: lambda do |input|
      base_sample = case input['object']
                    when 'employee', 'employee_new'
                      {
                        'fullName' => 'example',
                        'displayName' => 'example',
                        'creationDateTime' => '2024-03-27T09:12:21.680867',
                        'work' => {
                          'shortStartDate' => '01/05',
                          'startDate' => '01/05/2015',
                          'manager' => 'john doe',
                          'tenureDuration' => '9 years, 1 month and 26 days',
                          'durationOfEmployment' => '9 years, 1 month and 26 days',
                          'reportsToIdInCompany' => '30',
                          'employeeIdInCompany' => '40',
                          'reportsTo' => 'example',
                          'tenureDurationYears' => '9.155',
                          'department' => 'accounting',
                          'siteId' => 'example',
                          'tenureYears' => '9',
                          'isManager' => 'No',
                          'title' => 'engineer',
                          'site' => 'example',
                          'originalStartDate' => '01/05/2015',
                          'activeEffectiveDate' => '01/05/2015',
                          'secondLevelManager' => 'example',
                          'daysOfPreviousService' => '0',
                          'yearsOfService' => '9.155'
                        },
                        'avatarUrl' => 'string URL',
                        'secondName' => 'john',
                        'about' => {
                          'foodPreferences' => '',
                          'superpowers' => 'example',
                          'hobbies' => 'example',
                          'about' => 'string',
                          'avatar' => 'string URL'
                        },
                        'companyId' => '636192',
                        'email' => 'example@samplebob.com',
                        'surname' => 'example',
                        'coverImageUrl' => 'string URL',
                        'id' => '3332883884017713938',
                        'firstName' => 'example'
                      }
                    when 'company_list'
                      {
                        'name' => 'departments',
                        'label' => 'Departments',
                        'values' => [
                          {
                            'id' => 'hybrid',
                            'value' => 'Hybrid',
                            'name' => 'Hybrid',
                            'archived' => false
                          }
                        ],
                        'items' => [
                          {
                            'id' => 'hybrid',
                            'value' => 'Hybrid',
                            'name' => 'Hybrid',
                            'archived' => false
                          }
                        ]
                      }
                    when 'timeoff'
                      {
                        'policyTypeDisplayName' => 'Holiday',
                        'endDate' => '2025-08-06',
                        'description' => 'example',
                        'type' => 'days',
                        'createdOn' => '2025-08-17T17:07:54.414098',
                        'approved' => true,
                        'hasAttachment' => false,
                        'requestId' => 42_016_838,
                        'durationUnit' => 'days',
                        'totalDuration' => 1.5,
                        'visibility' => 'Public',
                        'employeeId' => '2911111434173677987',
                        'startPortion' => 'all_day',
                        'endPortion' => 'morning',
                        'totalCost' => 1.5,
                        'startDate' => '2025-08-05',
                        'status' => 'approved'
                      }
                    end
      base_sample.merge(call('rate_limit_sample_output'))
    end,

    search_records_sample_output: lambda do |input|
      base_sample = case input['object']
                    when 'employees_new'
                      {
                        'employees' => [
                          {
                            'fullName' => 'john',
                            'displayName' => 'john',
                            'creationDateTime' => '2024-03-27T09:12:21.680867',
                            'work' => {
                              'shortStartDate' => '01/05',
                              'startDate' => '01/05/2015',
                              'manager' => 'john doe',
                              'tenureDuration' => '9 years, 1 month and 26 days',
                              'durationOfEmployment' => '9 years, 1 month and 26 days',
                              'reportsToIdInCompany' => '30',
                              'employeeIdInCompany' => '40',
                              'reportsTo' => 'john doe',
                              'tenureDurationYears' => '9.155',
                              'department' => 'IT',
                              'siteId' => 'example',
                              'tenureYears' => '9',
                              'isManager' => 'No',
                              'title' => 'Engineer',
                              'site' => 'New York',
                              'originalStartDate' => '01/05/2015',
                              'activeEffectiveDate' => '01/05/2015',
                              'secondLevelManager' => 'example',
                              'daysOfPreviousService' => '0',
                              'yearsOfService' => '9.155'
                            },
                            'avatarUrl' => 'string URL',
                            'secondName' => 'example',
                            'about' => {
                              'foodPreferences' => '',
                              'superpowers' => 'example',
                              'hobbies' => 'example',
                              'about' => 'string',
                              'avatar' => 'string URL'
                            },
                            'companyId' => '636192',
                            'email' => 'example@samplebob.com',
                            'surname' => 'example',
                            'coverImageUrl' => 'string URL',
                            'id' => '3332883884017713938',
                            'firstName' => 'example'
                          }
                        ]
                      }
                    when 'company_list'
                      {
                        'company_lists' => [
                          {
                            'name' => 'departments',
                            'label' => 'Departments',
                            'values' => [
                              {
                                'id' => 'hybrid',
                                'value' => 'Hybrid',
                                'name' => 'Hybrid',
                                'archived' => false
                              }
                            ],
                            'items' => [
                              {
                                'id' => 'hybrid',
                                'value' => 'Hybrid',
                                'name' => 'Hybrid',
                                'archived' => false
                              }
                            ]
                          }
                        ]
                      }
                    when 'timeoff'
                      {
                        'outs' => [
                          {
                            'policyTypeDisplayName' => 'Holiday',
                            'endDate' => '2025-08-06',
                            'type' => 'days',
                            'createdOn' => '2025-08-17T17:07:54.414098',
                            'approved' => true,
                            'hasAttachment' => false,
                            'requestId' => 42_016_838,
                            'durationUnit' => 'days',
                            'totalDuration' => 1.5,
                            'visibility' => 'Public',
                            'employeeId' => '2911111434173677987',
                            'startPortion' => 'all_day',
                            'endPortion' => 'morning',
                            'totalCost' => 1.5,
                            'startDate' => '2025-08-05',
                            'status' => 'approved'
                          }
                        ]
                      }
                    when 'task'
                      {
                        'tasks' => [
                          {
                            'id' => 0,
                            'owner' => {
                              'id' => 'string',
                              'firstName' => 'john',
                              'surname' => 'doe',
                              'email' => 'test@gmail.com',
                              'displayName' => 'john'
                            },
                            'title' => 'string',
                            'requestedFor' => {
                              'id' => '123',
                              'firstName' => 'john',
                              'surname' => 'doe',
                              'email' => 'test@gmail.com',
                              'displayName' => 'john'
                            },
                            'due' => '2025-10-22',
                            'linkInBob' => 'string',
                            'set' => 'string',
                            'workflow' => 'string',
                            'ordinalInWorkflow' => 0,
                            'description' => 'string',
                            'status' => 'string',
                            'completionDate' => '2025-10-22',
                            'employeeGroupId' => 0,
                            'companyId' => 123
                          }
                        ]
                      }
                    when 'onboarding_wizard'
                      {
                        'wizards' => [
                          {
                            'id' => 123,
                            'name' => 'john doe'
                          }
                        ]
                      }
                    when 'company_field'
                      {
                        'values' => [
                          {
                            'categoryId' => 'root',
                            'categoryDisplayName' => 'Basic info',
                            'category' => 'root',
                            'name' => 'Company id',
                            'jsonPath' => 'companyId',
                            'type' => 'number',
                            'historical' => false
                          }
                        ]
                      }
                    end
      base_sample.merge(call('rate_limit_sample_output'))
    end,

    rate_limit_sample_output: lambda do
      {
        'x_ratelimit_limit' => 50,
        'x_ratelimit_remaining' => 49,
        'x_ratelimit_reset' => 1_760_380_440
      }
    end,

    generate_properties: lambda do |selected_fields, name_list, people_list|
      selected_fields.map do |field|
        base_schema =
          case field['type']
          when 'text-area'
            { type: 'text-area' }
          when 'date'
            { type: 'date' }
          when 'number'
            { type: 'number' }
          when 'list'
            {
              control_type: 'select',
              pick_list: call('custom_list', field['typeData']['listId'], name_list),
              type: 'string'
            }
          when 'multi-list'
            {
              control_type: 'multiselect',
              pick_list: call('custom_list', field['typeData']['listId'], name_list)
            }
          when 'employee-reference'
            {
              control_type: 'select',
              pick_list: call('employee_ref', people_list),
              type: 'string'
            }
          when 'currency'
            {
              type: 'object',
              properties: [
                {
                  name: 'value',
                  label: 'Value',
                  type: 'number',
                  convert_input: 'float_conversion',
                  optional: true
                },
                {
                  name: 'currency',
                  label: 'Currency',
                  type: 'string',
                  control_type: 'select',
                  pick_list: call('currency_list', 'currency', name_list),
                  optional: true
                }
              ]
            }

          when 'hierarchy-list'
            list_id = field['typeData']['listId']
            list_data = name_list&.find { |key, _value| key == list_id }&.last
            list = call('hierarchy_list', list_data['values'])
            {
              name: 'selected_item',
              label: 'Select from hierarchy',
              control_type: 'tree',
              tree_options: { selectable_folder: true },
              options: list,
              optional: true,
              toggle_hint: 'Select from hierarchy',
              convert_input: 'integer_conversion',
              toggle_field: {
                name: 'selected_item',
                type: 'string',
                control_type: 'text',
                label: 'Item ID',
                toggle_hint: 'Enter item ID manually'
              }
            }
          else
            {
              type: 'string'
            }
          end
        base_schema.merge(
          name: field['jsonPath'].split('.').last,
          label: field['name'] || field['id'],
          optional: true,
          hint: field['description']
        )
      end
    end,

    currency_list: lambda do |list_key, name_list|
      list_data = name_list[list_key] || {}
      list_data['items']&.map { |item| [item['name'], item['id']] } || []
    end,

    custom_list: lambda do |list_id, named_list|
      list_data = named_list&.find { |key, _value| key == list_id }&.last
      if list_data && list_data['values']
        list_data['values'].map { |item| [item['name'], item['id']] }
      else
        []
      end
    end,

    employee_ref: lambda do |people_list|
      people_list['employees']&.map { |item| [item['fullName'], item['id']] } || []
    end,

    hierarchy_list: lambda do |list_data|
      next false if list_data.length == 0

      list_data&.map do |item|
        [item['name'], item['id'], nil, call('hierarchy_list', item['children'])]
      end || []
    end,

    make_schema_builder_fields_sticky: lambda do |schema|
      schema.map do |field|
        if field['properties'].present?
          field['properties'] = call('make_schema_builder_fields_sticky', field['properties'])
        end
        field['sticky'] = true

        field
      end
    end,
    format_schema: lambda do |input|
      input&.map do |field|
        if (props = field[:properties])
          field[:properties] = call('format_schema', props)
        elsif (props = field['properties'])
          field['properties'] = call('format_schema', props)
        end
        if (name = field[:name])
          field[:label] = field[:label].presence || name.labelize
          field[:name] = name.gsub(/\W/) { |spl_chr| "__#{spl_chr.encode_hex}__" }
        elsif (name = field['name'])
          field['label'] = field['label'].presence || name.labelize
          field['name'] = name.gsub(/\W/) { |spl_chr| "__#{spl_chr.encode_hex}__" }
        end

        field
      end
    end,
    format_payload: lambda do |payload|
      if payload.is_a?(Array)
        payload.map do |array_value|
          call('format_payload', array_value)
        end
      elsif payload.is_a?(Hash)
        payload.each_with_object({}) do |(key, value), hash|
          key = key.gsub(/__[0-9a-fA-F]+__/) do |string|
            string.gsub('__', '').decode_hex.as_utf8
          end
          value = call('format_payload', value) if value.is_a?(Array) || value.is_a?(Hash)
          hash[key] = value
        end
      end
    end,
    format_response: lambda do |response|
      response = response&.compact unless response.is_a?(String) || response
      if response.is_a?(Array)
        response.map do |array_value|
          call('format_response', array_value)
        end
      elsif response.is_a?(Hash)
        response.each_with_object({}) do |(key, value), hash|
          key = key.gsub(/\W/) { |spl_chr| "__#{spl_chr.encode_hex}__" }
          value = call('format_response', value) if value.is_a?(Array) || value.is_a?(Hash)
          hash[key] = value
        end
      else
        response
      end
    end,
    generate_schema: lambda do |schema, parent, field|
      return schema if field['id'].match?(/\.reportsTo\.[^.]+$/)
      return schema if field['id'].match?(/\.payment\.[^.]+$/)

      if field['id'].include?('.')
        root = field['id'].split('.').first
        if root == 'root'
          field['id'] = field['id'].gsub("#{root}.", '')
          call('generate_schema', schema, parent, field)
        else
          if parent.include?(root)
            field['id'] = field['id'].gsub("#{root}.", '')
            parent_schema = schema.find { |sch| (sch[:name] == root) && sch[:properties] }
            schema.delete(parent_schema)
          else
            parent << root
          end
          field['id'] = field['id'].gsub("#{root}.", '')
          schema << { name: root, type: 'object',
                      properties: call('generate_schema',
                                       parent_schema&.[](:properties) ||
                                       [], parent, field) }
        end
      else
        parent << field['id']
        schema << { name: field['id'], label: field['name'].labelize }
      end
      schema
    end,
    human_readable_schema: lambda do |fields|
      (fields || []).map do |f|
        copy = {}
        f.each do |key, value|
          copy[key] = if key == :properties && value.is_a?(Array)
                        call('human_readable_schema', value)
                      else
                        value
                      end
        end
        copy
      end
    end,
    employee_get_output: lambda do |config = {}|
      schema = []
      parent = []

      get('v1/company/people/fields').
        each do |field|
          call('generate_schema', schema, parent, field)
        end
      work_schema = schema.find { |s| s[:name] == 'work' && s[:type] == 'object' }
      if work_schema&.[](:properties)
        work_schema[:properties].reject! { |p| p[:name] == 'reportsTo' }
        work_schema[:properties] << {
          name: 'reportsTo',
          type: 'object',
          properties: [
            { name: 'id', type: 'string' },
            { name: 'firstName', type: 'string' },
            { name: 'surname', type: 'string' },
            { name: 'email', type: 'string' },
            { name: 'displayName', type: 'string' }
          ]
        }
      end
      payroll_schema = schema.find { |s| s[:name] == 'payroll' && s[:type] == 'object' }
      if payroll_schema&.[](:properties)
        salary_schema = payroll_schema[:properties].
                        find { |p| p[:name] == 'salary' && p[:type] == 'object' }
        if salary_schema&.[](:properties)
          salary_schema[:properties].reject! { |p| p[:name] == 'payment' }
          salary_schema[:properties] << {
            name: 'payment',
            type: 'object',
            label: 'Payment',
            properties: [
              { name: 'value', type: 'number', label: 'Base salary' },
              { name: 'currency', type: 'string', label: 'Base salary currency code' }
            ]
          }
        end
      end
      if config['humanReadable'].to_s.upcase == 'APPEND' ||
         config['includeHumanReadable'].to_s == 'true'
        schema << {
          name: 'humanReadable',
          type: 'object',
          label: 'Human readable',
          properties: call('human_readable_schema', schema)
        }
      end
      schema
    end,
    search_url: lambda do |input|
      case input['object']
      when 'employees', 'employees_new'
        'people/search'
      when 'employee_work_history'
        "people/#{input.delete('id')}/work"
      when 'employee_employment_history'
        "people/#{input.delete('id')}/employment"
      when 'employee_salary_history'
        "people/#{input.delete('id')}/salaries"
      when 'employee_life_cycle_history'
        "people/#{input.delete('id')}/lifecycle"
      when 'company_list'
        'company/named-lists'
      when 'company_report'
        'company/reports'
      when 'company_field'
        'company/people/fields'
      when 'onboarding_wizard'
        'onboarding/wizards'
      when 'task'
        case input['query_type']
        when 'all_open_task'
          'tasks'
        when 'employee_task'
          "tasks/people/#{input.delete('id')}"
        end
      when 'timeoff'
        case input['query_type']
        when 'specific_date'
          'timeoff/outtoday'
        when 'date_range'
          'timeoff/whosout'
        when 'since_specific_date'
          'timeoff/requests/changes'
        end
      else
        input['object']
      end
    end,
    work_entry_update_input: lambda do
      [
        { name: 'entry_id', optional: false,
          hint: 'The entry id to update' }
      ].concat(call('work_entry_create_input'))
    end,
    work_entry_create_input: lambda do
      [
        { name: 'employee_id', label: 'Employee ID',
          optional: false },
        { name: 'id', sticky: true,
          type: 'integer', control_type: 'integer',
          convert_input: 'integer_conversion' },
        { name: 'reason', sticky: true,
          hint: 'Reason for this change' },
        { name: 'effectiveDate', optional: false,
          type: 'date', control_type: 'date',
          convert_input: 'date_conversion',
          hint: 'The date this entry becomes effective' },
        { name: 'title', sticky: true,
          hint: "The employee's job title" },
        { name: 'department', sticky: 'true',
          hint: "The employee's department" },
        { name: 'site', sticky: true,
          hint: "The employee's site" },
        { name: 'siteId', sticky: true,
          type: 'integer', control_type: 'integer',
          convert_input: 'integer_conversion',
          hint: "The employee's site ID" },
        { name: 'reportsTo', sticky: true, type: 'object',
          properties: [
            { name: 'id', label: 'Manager ID',
              optional: false,
              hint: "The manager's employee ID" },
            { name: 'firstName', sticky: true,
              hint: "The manager's first name" },
            { name: 'surname', sticky: true,
              hint: "The manager's surname" },
            { name: 'email', sticky: true, control_type: 'email',
              hint: "The manager's email" },
            { name: 'displayName', sticky: true,
              hint: "The manager's display name" }
          ] }
      ]
    end,
    employment_entry_create_input: lambda do
      call('work_entry_create_input').only('employee_id', 'id', 'reason', 'effectiveDate').
        push(

          { name: 'contract', sticky: true },
          { name: 'type', sticky: true },
          { name: 'salaryPayType', sticky: true }

        )
    end,
    salary_entry_create_input: lambda do
      call('work_entry_create_input').only('employee_id', 'id', 'reason', 'effectiveDate').
        push(

          { name: 'base', optional: false, type: 'object',
            properties: [
              { name: 'value', optional: false,
                type: 'number', control_type: 'number',
                convert_input: 'float_conversion' },
              { name: 'currency', optional: false,
                hint: '3 letter currency code. e.g. <b>USD</b>' }
            ] },
          { name: 'payPeriod', optional: false,
            control_type: 'select',
            pick_list: 'pay_period_list',
            toggle_hint: 'Select from list',
            toggle_field: {
              name: 'payPeriod', label: 'Pay period',
              optional: false,
              type: 'string', control_type: 'text',
              toggle_hint: 'Use custom value',
              hint: 'Allowed values are Annual, Hourly, Daily, Weekly, ' \
                    'Monthly.'
            } },
          { name: 'payFrequency', sticky: true,
            control_type: 'select',
            pick_list: 'pay_frequency_list',
            toggle_hint: 'Select from list',
            toggle_field: {
              name: 'payFrequency', label: 'Pay frequency',
              optional: true, sticky: true,
              type: 'string', control_type: 'text',
              toggle_hint: 'Use custom value',
              hint: 'Allowed values are Weekly, Monthly, Pro rata, ' \
                    'Every two weeks, Twice a month, Four weekly.'
            } }

        )
    end,
    variable_payment_create_input: lambda do
      call('work_entry_create_input').only('employee_id', 'id', 'reason', 'effectiveDate').
        push(

          { name: 'amount', type: 'object', optional: false,
            properties: [
              { name: 'value', optional: false,
                type: 'number', control_type: 'number',
                convert_input: 'float_conversion' },
              { name: 'currency', optional: false,
                hint: '3 letter currency code e.g. <b>USD</b>' }
            ] },
          { name: 'variableType', optional: false,
            hint: 'The type of the variable pay' },
          { name: 'paymentPeriod', optional: false,
            control_type: 'select',
            pick_list: 'payment_period_list',
            toggle_hint: 'Select from list',
            toggle_field: {
              name: 'paymentPeriod', label: 'Payment period',
              optional: false,
              type: 'string', control_type: 'text',
              toggle_hint: 'Use custom value',
              hint: 'Allowed values are Annual, Half-Yearly, ' \
                    'Quarterly, Monthly.'
            } },
          { name: 'companyPercent', sticky: true,
            type: 'integer', control_type: 'integer',
            convert_input: 'integer_conversion',
            hint: "The employee's company on-target weight in percent" },
          { name: 'departmentPercent', sticky: true,
            type: 'integer', control_type: 'integer',
            convert_input: 'integer_conversion',
            hint: "The employee's department on-target weight in percent" },
          { name: 'individualPercent', sticky: true,
            type: 'integer', control_type: 'integer',
            convert_input: 'integer_conversion',
            hint: "The employee's individual on-target weight in percent" }

        )
    end,
    training_record_create_input: lambda do
      call('work_entry_create_input').only('employee_id', 'id', 'reason', 'effectiveDate').
        push(

          { name: 'name', sticky: true,
            hint: 'Name of the training entry. The name must be of an ' \
                  'item in the training list field' },
          { name: 'description', sticky: true,
            hint: 'Further description about the training entery' },
          { name: 'cost', type: 'object', sticky: true,
            properties: [
              { name: 'value', optional: false,
                type: 'integer', control_type: 'integer',
                convert_input: 'integer_conversion' },
              { name: 'currency', optional: false,
                hint: '3 letter currency code e.g. <b>USD</b>' }
            ] },
          { name: 'status', sticky: true,
            hint: 'Status of the training entery' },
          { name: 'frequency', sticky: true,
            hint: 'Frequency of the training entry. The name must be of ' \
                  'an item in the frequency list field' },
          { name: 'startDate', sticky: true,
            type: 'date', control_type: 'date',
            convert_input: 'date_conversion',
            hint: 'The date this entry becomes effective' },
          { name: 'endDate', sticky: true,
            type: 'date', control_type: 'date',
            convert_input: 'date_conversion',
            hint: 'Date of training completion' },
          { name: 'documentId', sticky: true,
            type: 'integer', control_type: 'integer',
            convert_input: 'integer_conversion',
            hint: 'Document ID of the document attached to this ' \
                  'training entry' }

        )
    end,
    company_list_item_create_input: lambda do
      [
        { name: 'listName', optional: false,
          hint: 'Internal name of the list' },
        { name: 'name', optional: false,
          hint: 'Name of the item' },
        { name: 'parentId', sticky: true,
          type: 'integer',  control_type: 'integer',
          convert_input: 'integer_conversion',
          hint: 'ID of the new hierarchy parent node' }
      ]
    end,
    timeoff_request_create_input: lambda do
      [
        { name: 'id', label: 'Employee ID',
          optional: false },
        { name: 'policyType', optional: false,
          control_type: 'select',
          pick_list: 'timeoff_policy_list',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'policyType', label: 'Policy type',
            optional: false,
            type: 'string', control_type: 'text',
            toggle_hint: 'Use custom value',
            hint: 'Request policy type, e.g. Holiday, Sick or any ' \
                  'custom type defined'
          } },
        { name: 'requestRangeType', sticky: true,
          control_type: 'select',
          pick_list: 'timeoff_request_range_list',
          hint: 'Use hours when requesting several hours on a date. <b>This ' \
                'is supported only for policy types measured in hours</b>',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'requestRangeType', label: 'Request range type',
            optional: true, sticky: true,
            type: 'string', control_type: 'text',
            toggle_hint: 'Use custom value',
            hint: 'Use hours when requesting several hours on a date. <b>' \
                  'This is supported only for policy types measured in ' \
                  'hours</b>. Allowed values are hours, days.'
          } },
        { name: 'startDate', optional: false,
          type: 'date', control_type: 'date',
          convert_input: 'date_conversion',
          hint: 'Date of the first day of the time off' },
        { name: 'startDatePortion', sticky: true,
          control_type: 'select',
          pick_list: 'timeoff_request_range_list',
          hint: 'Portion of the first day - relevant for requests in days',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'startDatePortion', label: 'Start date portion',
            optional: true, sticky: true,
            type: 'string', control_type: 'text',
            toggle_hint: 'Use custom value',
            hint: 'Portion of the first day - relevant for requests in ' \
                  'days. Allowed values are all_day, morning, afternoon.'
          } },
        { name: 'endDate', sticky: true,
          type: 'date', control_type: 'date',
          convert_input: 'date_conversion',
          hint: 'Date of the last day of the time off - relevant ' \
                'for requests in days' },
        { name: 'hours', sticky: true,
          type: 'integer', control_type: 'integer',
          convert_input: 'integer_conversion',
          hint: 'This field is mandatory if the requestRangeType ' \
                "is set to 'hours'" },
        { name: 'endDatePortion', sticky: true,
          control_type: 'select',
          pick_list: 'timeoff_request_range_list',
          hint: 'Portion of the last day - relevant for requests in days',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'endDatePortion', label: 'End date portion',
            optional: true, sticky: true,
            type: 'string', control_type: 'text',
            toggle_hint: 'Use custom value',
            hint: 'Portion of the last day - relevant for requests in ' \
                  'days. Allowed values are all_day, morning, afternoon.'
          } },
        { name: 'skipManagerApproval', sticky: true,
          type: 'boolean', control_type: 'checkbox',
          convert_input: 'boolean_conversion',
          hint: 'Admins only can skip the approval policy, setting this ' \
                'field to true will create an approved request.',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'skipManagerApproval', label: 'Skip manager approval',
            type: 'string', control_type: 'text',
            optional: true, sticky: true,
            convert_input: 'boolean_conversion',
            hint: 'Admins only can skip the approval policy, setting ' \
                  'this field to true will create an approved request. ' \
                  'Accepted values are true or false.',
            toggle_hint: 'Use custom value'
          } },
        { name: 'approver', sticky: true,
          hint: 'Employee ID of the user to be set as the approver for ' \
                "this request - relevant if 'skipManagerApproval' set to " \
                'true Please note that the user calling the api with ' \
                'this param must have permission to import timeoff requests' },
        { name: 'description', sticky: true,
          hint: 'Request reason' }
      ]
    end,
    webhook_v2_data_schema: lambda do |event, event_type|
      case event
      when 'employee'
        if event_type == 'employee.updated'
          [
            { name: 'employeeId' },
            {
              name: 'fieldUpdatesIds',
              label: 'Field updates IDs',
              type: 'array',
              of: 'object',
              properties: [
                { name: 'id' }
              ]
            }
          ]
        elsif event_type.starts_with?('table.entry')
          [
            { name: 'employeeId' },
            { name: 'tableId' },
            { name: 'effectiveDate', type: 'date' },
            { name: 'id', type: 'integer' }
          ]
        else
          [
            { name: 'employeeId' }
          ]
        end
      when 'time_off'
        [
          { name: 'timeoffRequestId', type: 'integer' },
          { name: 'employeeId' },
          { name: 'getApi', label: 'Get API' },
          { name: 'originalRequestId', type: 'integer' },
          { name: 'previousRequestId', type: 'integer' }
        ]
      when 'task'
        if event_type.ends_with?('assign')
          [
            { name: 'requestedForEmployeeId' },
            { name: 'workflowId', type: 'integer' },
            { name: 'pivotDate', type: 'date' },
            {
              name: 'toDoIds',
              label: 'To do IDs',
              type: 'array',
              of: 'object',
              properties: [
                { name: 'id', type: 'integer' }
              ]
            }
          ]
        else
          [
            {
              name: 'toDoIds',
              label: 'To do IDs',
              type: 'array',
              of: 'object',
              properties: [
                { name: 'id', type: 'integer' }
              ]
            },
            {
              name: 'toDoRequestedForIds',
              label: 'To do requested for IDs',
              type: 'array',
              of: 'string'
            },
            {
              name: 'toDoAssigneeIds',
              label: 'To do assignee IDs',
              type: 'array',
              of: 'string'
            },
            { name: 'newStatus' }
          ]
        end
      when 'document'
        [
          { name: 'employeeId' },
          { name: 'documentId', type: 'integer' },
          { name: 'downloadUrl' },
          { name: 'signedBy' },
          { name: 'creationDate', type: 'date_time' }
        ]
      when 'workforce_planning'
        case event_type
        when 'workforcePlanning.position.created'
          [
            { name: 'positionId', type: 'integer' }
          ]
        when 'workforcePlanning.positionOpening.created',
          'workforcePlanning.positionOpening.deleted'
          [
            { name: 'positionOpeningId', type: 'integer' }
          ]
        when 'workforcePlanning.positionBudget.created'
          [
            { name: 'positionBudgetId', type: 'integer' },
            { name: 'positionId', type: 'integer' }
          ]
        when 'workforcePlanning.position.updated'
          [
            { name: 'positionId', type: 'integer' },
            {
              name: 'fieldUpdatesIds',
              label: 'Field updates IDs',
              type: 'array',
              of: 'object',
              properties: [
                { name: 'id' }
              ]
            }
          ]
        when 'workforcePlanning.positionOpening.updated'
          [
            { name: 'positionOpeningId', type: 'integer' },
            {
              name: 'fieldUpdatesIds',
              label: 'Field updates IDs',
              type: 'array',
              of: 'object',
              properties: [
                { name: 'id' }
              ]
            }
          ]
        when 'workforcePlanning.positionBudget.updated'
          [
            { name: 'positionBudgetId', type: 'integer' },
            { name: 'positionId', type: 'integer' },
            { name: 'entityType', type: 'string' },
            {
              name: 'fieldUpdatesIds',
              label: 'Field updates IDs',
              type: 'array',
              of: 'object',
              properties: [
                { name: 'id' }
              ]
            }
          ]
        end
      end
    end,
    sample_webhook_output: lambda do |event, event_type|
      case event
      when 'employee'
        if event_type == 'employee.updated'
          {
            companyId: 637_323,
            type: 'employee.updated',
            triggeredBy: '3332883804594373380',
            triggeredAt: '2024-12-26T11:29:14.399997',
            data: {
              employeeId: '3332883894235038486',
              fieldUpdatesIds: [
                {
                  id: 'personal.birthDate'
                }
              ]
            }
          }
        elsif event_type.starts_with?('table.entry')
          {
            companyId: 636_192,
            type: event_type,
            triggeredBy: '3332883804594373380',
            triggeredAt: '2025-01-08T13:06:26.915906',
            version: 'v2',
            data: {
              employeeId: '3332883854254932743',
              tableId: 'lifecycle',
              effectiveDate: '2025-01-08'
            }
          }
        else
          {
            companyId: 637_323,
            type: event_type,
            triggeredBy: '3332883804594373380',
            triggeredAt: '2024-12-26T11:29:14.399997',
            data: {
              employeeId: '3332883894235038486'
            }
          }
        end
      when 'time_off'
        {
          companyId: 636_192,
          type: event_type,
          triggeredBy: '3332883804594373380',
          triggeredAt: '2025-02-18T16:15:00.218602',
          version: 'v2',
          data: {
            timeoffRequestId: 34_902_625,
            employeeId: '3332883884017713938',
            getApi: 'https://api.hibob.com/v1/timeoff/employees/3332883884017713938/requests/34900183',
            originalRequestId: 34_615_592,
            previousRequestId: 34_900_183
          }
        }
      when 'task'
        if event_type.ends_with?('assign')
          {
            companyId: 636_192,
            type: 'todo.assign',
            triggeredBy: '3332883804594373380',
            triggeredAt: '2025-01-08T12:12:31.199878',
            version: 'v2',
            data: {
              requestedForEmployeeId: '3332883884017713938',
              workflowId: 2_302_289,
              pivotDate: '2025-01-08',
              toDoIds: [
                {
                  id: 32_261_122
                }
              ]
            }
          }
        else
          {
            companyId: 636_192,
            type: 'todo.changedStatus',
            triggeredBy: '3332883804594373380',
            triggeredAt: '2025-01-08T12:10:22.297354',
            version: 'v2',
            data: {
              toDoIds: [
                {
                  id: 32_008_655
                }
              ],
              toDoRequestedForIds: [
                '3332883881626960657'
              ],
              toDoAssigneeIds: [
                '3332883804594373380'
              ],
              newStatus: 'Closed'
            }
          }
        end
      when 'document'
        {
          companyId: 637_323,
          type: 'documents.eSign.completed',
          triggeredBy: 'system',
          triggeredAt: '2024-10-03T09:29:00.831502',
          version: 'v2',
          data: {
            employeeId: '3418533772247696340',
            documentId: 17_745_922,
            downloadUrl: 'https://app.hibob.com/api/docs/...',
            signedBy: '3418533772247696340',
            creationDate: '2024-10-03T09:26:33.864255'
          }
        }
      when 'workforce_planning'
        base = {
          companyId: 637_23,
          type: event_type,
          triggeredBy: '3418533772247696340',
          triggeredAt: '2024-10-03T09:29:00.831502',
          version: 'v2'
        }
        case event_type
        when 'workforcePlanning.position.created'
          base.merge(
            data: {
              positionId: 123
            }
          )
        when 'workforcePlanning.position.updated'
          base.merge(
            data: {
              positionId: 123,
              fieldUpdatesIds: [
                { id: '/position/status' }
              ]
            }
          )
        when 'workforcePlanning.positionOpening.created',
          'workforcePlanning.positionOpening.deleted'
          base.merge(
            data: {
              positionOpeningId: 456
            }
          )
        when 'workforcePlanning.positionOpening.updated'
          base.merge(
            data: {
              positionOpeningId: 456,
              fieldUpdatesIds: [
                { id: '/positionOpening/status' }
              ]
            }
          )

        when 'workforcePlanning.positionBudget.created'
          base.merge(
            data: {
              positionBudgetId: 789,
              positionId: 123
            }
          )
        when 'workforcePlanning.positionBudget.updated'
          base.merge(
            data: {
              positionBudgetId: 789,
              positionId: 123,
              entityType: 'positionBudget',
              fieldUpdatesIds: [
                { id: '/positionBudget/status' }
              ]
            }
          )
        end
      end
    end,
    employee_trigger_output: lambda do
      [
        { name: 'companyId',
          type: 'integer', control_type: 'integer',
          convert_output: 'integer_conversion' },
        { name: 'employee',
          type: 'object',
          properties: [
            { name: 'id', label: 'Employee ID' },
            { name: 'companyId',
              type: 'integer',
              control_type: 'integer',
              convert_output: 'integer_conversion' },
            { name: 'firstName' },
            { name: 'surname' },
            { name: 'email' },
            { name: 'displayName' },
            { name: 'avatar' },
            { name: 'site' },
            { name: 'siteId',
              type: 'integer',
              control_type: 'integer',
              convert_output: 'integer_conversion' }
          ] },
        { name: 'changedBy',
          type: 'object',
          properties: [
            { name: 'id', label: 'Employee ID' },
            { name: 'companyId',
              type: 'integer',
              control_type: 'integer',
              convert_output: 'integer_conversion' },
            { name: 'firstName' },
            { name: 'surname' },
            { name: 'email' },
            { name: 'displayName' },
            { name: 'avatar' },
            { name: 'site' },
            { name: 'siteId',
              type: 'integer',
              control_type: 'integer',
              convert_output: 'integer_conversion' }
          ] },
        { name: 'type' },
        { name: 'data',
          type: 'object',
          properties: call('employee_get_output') },
        { name: 'previous' },
        { name: 'creationDate' }
      ]
    end,
    employee_updated_trigger_output: lambda do
      [
        { name: 'companyId',
          type: 'integer', control_type: 'integer',
          convert_output: 'integer_conversion' },
        { name: 'employee',
          type: 'object',
          properties: [
            { name: 'id', label: 'Employee ID' },
            { name: 'companyId',
              type: 'integer',
              control_type: 'integer',
              convert_output: 'integer_conversion' },
            { name: 'firstName' },
            { name: 'surname' },
            { name: 'email' },
            { name: 'displayName' },
            { name: 'avatar' },
            { name: 'site' },
            { name: 'siteId',
              type: 'integer',
              control_type: 'integer',
              convert_output: 'integer_conversion' }
          ] },
        { name: 'changedBy',
          type: 'object',
          properties: [
            { name: 'id', label: 'Employee ID' },
            { name: 'companyId',
              type: 'integer',
              control_type: 'integer',
              convert_output: 'integer_conversion' },
            { name: 'firstName' },
            { name: 'surname' },
            { name: 'email' },
            { name: 'displayName' },
            { name: 'avatar' },
            { name: 'site' },
            { name: 'siteId',
              type: 'integer',
              control_type: 'integer',
              convert_output: 'integer_conversion' }
          ] },
        { name: 'type' },
        { name: 'data',
          type: 'object',
          properties: [
            { name: 'fieldUpdates', type: 'array', of: 'object',
              properties: [
                { name: 'id' },
                { name: 'path' },
                { name: 'originalValue' },
                { name: 'newValue' }
              ] }
          ] },
        { name: 'previous' },
        { name: 'creationDate' }
      ]
    end,
    document_trigger_output: lambda do
      [
        { name: 'companyId',
          type: 'integer', control_type: 'integer',
          convert_output: 'integer_conversion' },
        { name: 'type' },
        { name: 'documentId',
          type: 'integer', control_type: 'integer',
          convert_output: 'integer_conversion' },
        { name: 'employeeId' },
        { name: 'downloadUrl', control_type: 'url' },
        { name: 'signedBy' },
        { name: 'creationDate', type: 'date_time', control_type: 'date_time' }
      ]
    end,
    task_status_changed_trigger_output: lambda do
      [
        { name: 'companyId',
          type: 'integer', control_type: 'integer',
          convert_output: 'integer_conversion' },
        { name: 'changedById' },
        { name: 'changedByName' },
        { name: 'newStatus' },
        { name: 'toDoId', type: 'array', of: 'integer' },
        { name: 'toDoRequestedForId', type: 'array', of: 'string' },
        { name: 'toDoAssigneeId', type: 'array', of: 'string' },
        { name: 'toDoAssigneeName', type: 'array', of: 'string' },
        { name: 'toDoTitle', type: 'array', of: 'string' },
        { name: 'type' },
        { name: 'modificationDate', type: 'date_time', control_type: 'date_time' }
      ]
    end,
    task_trigger_output: lambda do
      [
        { name: 'companyId',
          type: 'integer',
          control_type: 'integer',
          convert_output: 'integer_conversion' },
        { name: 'changedBy',
          type: 'object',
          properties: [
            { name: 'id', label: 'Employee ID' },
            { name: 'companyId',
              type: 'integer',
              control_type: 'integer',
              convert_output: 'integer_conversion' },
            { name: 'firstName' },
            { name: 'surname' },
            { name: 'email' },
            { name: 'displayName' },
            { name: 'site' },
            { name: 'siteId',
              type: 'integer',
              control_type: 'integer',
              convert_output: 'integer_conversion' }
          ] },
        { name: 'toDos',
          type: 'array',
          of: 'object',
          properties: [
            { name: 'id',
              type: 'integer',
              control_type: 'integer',
              convert_output: 'integer_conversion' },
            { name: 'owner',
              type: 'object',
              properties: [
                { name: 'id' },
                { name: 'firstName' },
                { name: 'surname' },
                { name: 'email' },
                { name: 'displayName' }
              ] },
            { name: 'title' },
            { name: 'requestedFor',
              type: 'object',
              properties: [
                { name: 'id' },
                { name: 'firstName' },
                { name: 'surname' },
                { name: 'email' },
                { name: 'displayName' }
              ] },
            { name: 'due' },
            { name: 'linkInBob' },
            { name: 'set' },
            { name: 'workflow' },
            { name: 'ordinalInWorkflow',
              type: 'integer',
              control_type: 'integer',
              convert_output: 'integer_conversion' },
            { name: 'description' },
            { name: 'status' },
            { name: 'completionDate' }
          ] },
        { name: 'requestedFor',
          type: 'object',
          properties: [
            { name: 'id' },
            { name: 'companyId',
              type: 'integer',
              control_type: 'integer',
              convert_output: 'integer_conversion' },
            { name: 'firstName' },
            { name: 'surname' },
            { name: 'email' },
            { name: 'displayName' },
            { name: 'site' },
            { name: 'siteId',
              type: 'integer',
              control_type: 'integer',
              convert_output: 'integer_conversion' }
          ] },
        { name: 'pivotDate' },
        { name: 'assignmentType' },
        { name: 'workflow',
          type: 'object',
          properties: [
            { name: 'id',
              type: 'integer',
              control_type: 'integer',
              convert_output: 'integer_conversion' },
            { name: 'name' },
            { name: 'message' },
            { name: 'automaticTriggerEnabled',
              type: 'boolean',
              control_type: 'checkbox',
              convert_output: 'boolean_conversion' },
            { name: 'automaticTrigger',
              type: 'object',
              properties: [] },
            { name: 'filter',
              type: 'array',
              of: 'object',
              properties: [
                { name: 'fieldPath' },
                { name: 'operator' },
                { name: 'values',
                  type: 'array',
                  of: 'string' }
              ] },
            { name: 'owner' }
          ] },
        { name: 'type' },
        { name: 'creationDate', type: 'date_time', control_type: 'date_time' }
      ]
    end,
    employees_search_input: lambda do |_input|
      [
        { name: 'showInactive', sticky: true,
          type: 'boolean', control_type: 'checkbox',
          convert_input: 'boolean_conversion',
          hint: 'Should include inactive employees',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'showInactive', label: 'Show inactive',
            type: 'string', control_type: 'text',
            optional: true, sticky: true,
            convert_input: 'boolean_conversion',
            hint: 'Should include inactive employees. Accepted values are ' \
                  'true or false',
            toggle_hint: 'Use custom value'
          } },
        { name: 'humanReadable', sticky: true,
          extends_schema: true,
          type: 'boolean', control_type: 'checkbox',
          convert_input: 'boolean_conversion',
          hint: 'Whether to supply human-readable values in JSON instead of ' \
                'machine-readable',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'humanReadable', label: 'Human readable',
            extends_schema: true,
            type: 'string', control_type: 'text',
            optional: true, sticky: true,
            convert_input: 'boolean_conversion',
            hint: 'Whether to supply human-readable values in JSON instead ' \
                  'of machine-readable. Accepted values are true or false',
            toggle_hint: 'Use custom value'
          } },
        { name: 'includeHumanReadable', sticky: true,
          extends_schema: true,
          type: 'boolean', control_type: 'checkbox',
          convert_input: 'boolean_conversion',
          hint: 'Whether to include the additional "humanReadable" JSON ' \
                'node in the response',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'includeHumanReadable', label: 'Include human readable',
            extends_schema: true,
            type: 'string', control_type: 'text',
            optional: true, sticky: true,
            convert_input: 'boolean_conversion',
            hint: 'Whether to include the additional "humanReadable" JSON ' \
                  'node in the response. Accepted values are true or false',
            toggle_hint: 'Use custom value'
          } }
      ]
    end,
    employees_new_search_input: lambda do |_input|
      [
        { name: 'showInactive', sticky: true,
          type: 'boolean', control_type: 'checkbox',
          convert_input: 'boolean_conversion',
          convert_output: 'boolean_conversion',
          hint: 'Should include inactive employees',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'showInactive', label: 'Show inactive',
            type: 'string', control_type: 'text',
            optional: true, sticky: true,
            convert_input: 'boolean_conversion',
            convert_output: 'boolean_conversion',
            hint: 'Should include inactive employees. Accepted values are ' \
                  'true or false',
            toggle_hint: 'Use custom value'
          } },
        { name: 'humanReadable', sticky: true,
          extends_schema: true,
          type: 'string', control_type: 'select',
          pick_list: [
            %w[Append APPEND],
            %w[Replace REPLACE]
          ],
          hint: 'Whether to supply human-readable values in JSON instead of ' \
                'machine-readable',
          optional: true,
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'humanReadable', label: 'Human readable',
            extends_schema: true,
            type: 'string', control_type: 'text',
            optional: true, sticky: true,
            hint: 'Whether to supply human-readable values in JSON instead ' \
                  'of machine-readable. Accepted values are <b>APPEND</b> or <b>REPLACE</b>',
            toggle_hint: 'Use custom value'
          } },
        {
          name: 'fields',
          label: 'Fields to retrieve',
          pick_list: 'fields_to_retrieve',
          control_type: 'multiselect',
          delimiter: ',',
          optional: true,
          sticky: true,
          type: 'string',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'fields',
            label: 'Fields to retrieve',
            optional: true,
            type: 'string',
            control_type: 'text',
            toggle_hint: 'Use custom value',
            hint: 'Provide a comma-separated list of fields. For basic fields, ' \
                  "add a prefix 'root', for example, 'root.firstName'. " \
                  'For category fields, add the category name as a prefix, ' \
                  "for example, 'work.department'. " \
                  '<a href="https://apidocs.hibob.com/reference/post_people-search"' \
                  'target="_blank">Learn more</a>'
          }
        },
        {
          name: 'filters',
          type: 'array',
          of: 'object',
          hint: 'Optional list of filters for filtering employees. ' \
                'We currently support up to one filter.',
          properties: [
            { name: 'fieldPath',
              type: 'string',
              control_type: 'select',
              pick_list: [
                ['ID', 'root.id'],
                ['Email', 'root.email']
              ] },
            { name: 'operator',
              type: 'string',
              control_type: 'select',
              pick_list: [
                %w[Equals equals]
              ] },
            { name: 'values',
              type: 'array',
              of: 'string',
              hint: 'List of values to compare.' }
          ]
        }
      ]
    end,
    task_search_input: lambda do |input|
      schema = [
        { name: 'query_type', control_type: 'select',
          optional: false, extends_schema: true,
          pick_list: %w[all_open_task employee_task].
            map { |e| [e.labelize, e] },
          hint: 'Select any Task query type, e.g. My task.' }
      ]
      if input['query_type'].present? && input['query_type'] == 'employee_task'
        schema.push(
          { name: 'id', label: 'Employee ID',
            optional: false },
          { name: 'task_status',
            sticky: true, control_type: 'select',
            pick_list: %w[open closed].map { |e| [e.labelize, e] },
            toggle_hint: 'Select from list',
            toggle_field: {
              name: 'task_status', label: 'Task status',
              optional: true, sticky: true,
              type: 'string', control_type: 'text',
              toggle_hint: 'Use custom value',
              hint: 'Filter tasks by open / closed status. not sending ' \
                    'task status will return all tasks. Allowed values ' \
                    'are open or closed.'
            } }
        )
      end
      schema
    end,
    timeoff_search_input: lambda do |input|
      schema = if input['query_type'].present?
                 case input['query_type']
                 when 'specific_date'
                   [
                     { name: 'today', label: 'Specific date', sticky: true,
                       type: 'date', control_type: 'date',
                       convert_input: 'date_conversion',
                       hint: 'Date to report out of the office. If not specified, ' \
                             'the date at UTC at the time of the request is used' },
                     { name: 'includeHourly', sticky: true,
                       type: 'boolean', control_type: 'checkbox',
                       convert_input: 'boolean_conversion',
                       toggle_hint: 'Select from list',
                       toggle_field: {
                         name: 'includeHourly', label: 'Include hourly',
                         type: 'string', control_type: 'text',
                         optional: true, sticky: true,
                         convert_input: 'boolean_conversion',
                         hint: 'Accepted values are true or false',
                         toggle_hint: 'Use custom value'
                       } }
                   ]
                 when 'date_range'
                   [
                     { name: 'from', label: 'Start period date',
                       optional: false,
                       type: 'date', control_type: 'date',
                       convert_input: 'date_conversion' },
                     { name: 'to', label: 'End period date',
                       optional: false,
                       type: 'date', control_type: 'date',
                       convert_input: 'date_conversion' },
                     { name: 'includeHourly', sticky: true,
                       type: 'boolean', control_type: 'checkbox',
                       convert_input: 'boolean_conversion',
                       toggle_hint: 'Select from list',
                       toggle_field: {
                         name: 'includeHourly', label: 'Include hourly',
                         type: 'string', control_type: 'text',
                         optional: true, sticky: true,
                         convert_input: 'boolean_conversion',
                         hint: 'Accepted values are true or false',
                         toggle_hint: 'Use custom value'
                       } }
                   ]
                 when 'since_specific_date'
                   [
                     { name: 'since', optional: false,
                       type: 'date_time', control_type: 'date_time',
                       convert_input: 'render_iso8601_timestamp',
                       hint: 'Timestamp starting from which to return ' \
                             'the changes.' }
                   ]
                 end
               else
                 []
               end
      [
        { name: 'query_type', control_type: 'select',
          optional: false, extends_schema: true,
          pick_list: %w[specific_date date_range since_specific_date].
            map { |e| [e.labelize, e] },
          hint: 'Select any timeoff query type, e.g. Specific date.' }
      ].concat(schema)
    end,
    timeoff_search_output: lambda do |input|
      case input['query_type']
      when 'specific_date'
        [
          { name: 'outs', label: 'Timeoff',
            type: 'array', of: 'object',
            properties: call('timeoff_schema').
              ignored('requestId', 'policyType', 'changeType',
                      'employeeEmail', 'employeeDisplayName') }
        ]
      when 'date_range'
        [
          { name: 'outs', label: 'Timeoff',
            type: 'array', of: 'object',
            properties: call('timeoff_schema').
              ignored('requestRangeType', 'changeType', 'employeeEmail', 'date',
                      'hoursOnDate') }
        ]
      when 'since_specific_date'
        [
          { name: 'changes', label: 'Timeoff',
            type: 'array', of: 'object',
            properties: call('timeoff_schema').
              ignored('requestRangeType', 'status', 'policyType', 'date',
                      'hoursOnDate').
              push(
                { name: 'totalDuration', type: 'number' },
                { name: 'originalRequestId' },
                { name: 'changeReason' },
                { name: 'createdOn' },
                { name: 'durationUnit' },
                { name: 'previousRequestId' },
                { name: 'totalCost', type: 'number' }
              ) }
        ]
      else
        []
      end
    end,
    timeoff_schema: lambda do
      [
        { name: 'changeType' },
        { name: 'requestId',
          type: 'integer', control_type: 'integer',
          convert_output: 'integer_conversion' },
        { name: 'employeeId' },
        { name: 'employeeEmail', control_type: 'email' },
        { name: 'employeeDisplayName' },
        { name: 'policyType' },
        { name: 'policyTypeDisplayName' },
        { name: 'type' },
        { name: 'startDate', type: 'date', control_type: 'date',
          convert_output: 'date_conversion' },
        { name: 'startPortion' },
        { name: 'endDate', type: 'date', control_type: 'date',
          convert_output: 'date_conversion' },
        { name: 'endPortion' },
        { name: 'requestRangeType' },
        { name: 'date', type: 'date', control_type: 'date',
          convert_output: 'date_conversion' },
        { name: 'hoursOnDate',
          type: 'integer', control_type: 'integer',
          convert_output: 'integer_conversion' },
        { name: 'status' },
        { name: 'visibility' }
      ]
    end,
    timeoff_get_input: lambda do
      [
        { name: 'id', label: 'Employee ID',
          optional: false },
        { name: 'requestId', optional: false }
      ]
    end,
    timeoff_get_output: lambda do
      call('timeoff_schema').ignored('changeType', 'employeeEmail',
                                     'employeeDisplayName', 'policyType',
                                     'requestRangeType').
        push(

          { name: 'approved', type: 'boolean',
            control_type: 'checkbox',
            convert_output: 'boolean_conversion' },
          { name: 'attachmentLinks', type: 'array', of: 'object',
            properties: [
              { name: 'filename' },
              { name: 'url' },
              { name: 'mimeType' }
            ] },
          { name: 'timeZoneOffset' },
          { name: 'approvedBy' },
          { name: 'description' },
          { name: 'createdOn' },
          { name: 'declinedAt' },
          { name: 'hasAttachment', type: 'boolean' },
          { name: 'reasonCode' },
          { name: 'durationUnit' },
          { name: 'declineReason' },
          { name: 'totalDuration', type: 'number' },
          { name: 'originalRequestId' },
          { name: 'declinedBy' },
          { name: 'approvedAt' },
          { name: 'previousRequestId' },
          { name: 'totalCost', type: 'number' }

        )
    end,
    task_search_output: lambda do |_input|
      [
        { name: 'tasks', type: 'array', of: 'object',
          properties: [
            { name: 'id',
              type: 'integer', control_type: 'integer',
              convert_output: 'integer_conversion' },
            { name: 'title' },
            { name: 'set' },
            { name: 'description' },
            { name: 'owner', type: 'object',
              properties: [
                { name: 'id' },
                { name: 'firstName' },
                { name: 'surname' },
                { name: 'email' },
                { name: 'displayName' }
              ] },
            { name: 'requestedFor', type: 'object',
              properties: [
                { name: 'id' },
                { name: 'firstName' },
                { name: 'surname' },
                { name: 'email' },
                { name: 'displayName' }
              ] },
            { name: 'due', type: 'date', control_type: 'date',
              convert_output: 'date_conversion' },
            { name: 'linkInBob' },
            { name: 'workflow' },
            { name: 'ordinalInWorkflow',
              type: 'integer', control_type: 'integer',
              convert_output: 'integer_conversion' },
            { name: 'status' },
            { name: 'completionDate', type: 'date' },
            { name: 'employeeGroupId', type: 'integer' },
            { name: 'companyId', type: 'integer' }
          ] }
      ]
    end,
    employees_search_output: lambda do |config_fields = {}|
      [
        { name: 'employees', type: 'array', of: 'object',
          properties: call('employee_get_output', config_fields) }
      ]
    end,
    employees_search_search_output: lambda do |config_fields = {}|
      [
        { name: 'employees', type: 'array', of: 'object',
          properties: call('employee_get_output', config_fields) }
      ]
    end,
    employee_work_history_search_output: lambda do
      [
        { name: 'values', label: "Employee's work history",
          type: 'array', of: 'object',
          properties: [
            { name: 'id',
              type: 'integer', control_type: 'integer',
              convert_output: 'integer_conversion' },
            { name: 'reason' },
            { name: 'effectiveDate', type: 'date', control_type: 'date',
              convert_output: 'date_conversion' },
            { name: 'endEffectiveDate', type: 'date', control_type: 'date',
              convert_output: 'date_conversion' },
            { name: 'isCurrent',
              type: 'boolean', control_type: 'checkbox',
              convert_output: 'boolean_conversion' },
            { name: 'canBeDeleted',
              type: 'boolean', control_type: 'checkbox',
              convert_output: 'boolean_conversion' },
            { name: 'change', type: 'object',
              properties: [
                { name: 'reason' },
                { name: 'changedBy' },
                { name: 'changedById' }
              ] },
            { name: 'creationDate' },
            { name: 'modificationDate' },
            { name: 'title' },
            { name: 'department' },
            { name: 'site' },
            { name: 'siteId',
              type: 'integer', control_type: 'integer',
              convert_output: 'integer_conversion' },
            { name: 'reportsTo', type: 'object',
              properties: [
                { name: 'id', label: 'Manager ID' },
                { name: 'firstName' },
                { name: 'surname' },
                { name: 'email', control_type: 'email' },
                { name: 'displayName' }
              ] },
            { name: 'activeEffectiveDate', type: 'date', control_type: 'date',
              convert_output: 'date_conversion' },
            { name: 'workChangeType' },
            { name: 'customColumns', type: 'object',
              properties: [] }
          ] }
      ]
    end,
    employee_employment_history_search_output: lambda do
      [
        { name: 'values', label: "Employee's employment history",
          type: 'array', of: 'object',
          properties: [
            { name: 'id',
              type: 'integer', control_type: 'integer',
              convert_output: 'integer_conversion' },
            { name: 'reason' },
            { name: 'effectiveDate',
              type: 'date', control_type: 'date',
              convert_output: 'date_conversion' },
            { name: 'endEffectiveDate',
              type: 'date', control_type: 'date',
              convert_output: 'date_conversion' },
            { name: 'isCurrent',
              type: 'boolean', control_type: 'checkbox',
              convert_output: 'boolean_conversion' },
            { name: 'canBeDeleted',
              type: 'boolean', control_type: 'checkbox',
              convert_output: 'boolean_conversion' },
            { name: 'change', type: 'object',
              properties: [
                { name: 'reason' },
                { name: 'changedBy' },
                { name: 'changedById' }
              ] },
            { name: 'creationDate',
              type: 'date', control_type: 'date',
              convert_output: 'date_conversion' },
            { name: 'modificationDate',
              type: 'date', control_type: 'date',
              convert_output: 'date_conversion' },
            { name: 'contract' },
            { name: 'type' },
            { name: 'workingPattern' },
            { name: 'siteWorkingPattern', type: 'object',
              properties: [
                { name: 'workingPatternType' },
                { name: 'days', type: 'object',
                  properties: [
                    { name: 'sunday' },
                    { name: 'monday' },
                    { name: 'tuesday' },
                    { name: 'wednesday' },
                    { name: 'thursday' },
                    { name: 'friday' },
                    { name: 'saturday' }
                  ] },
                { name: 'hoursPerDay',
                  type: 'integer', control_type: 'integer',
                  convert_output: 'integer_conversion' },
                { name: 'workingPatternId', type: 'integer' }
              ] },
            { name: 'calendarName' },
            { name: 'calendarId' },
            { name: 'flsaCode', label: 'FLSA code' },
            { name: 'salaryPayType' },
            { name: 'fte', label: 'FTE',
              type: 'integer', control_type: 'integer',
              convert_output: 'integer_conversion' },
            { name: 'weeklyHours',
              type: 'integer', control_type: 'integer',
              convert_output: 'integer_conversion' },
            { name: 'activeEffectiveDate',
              type: 'date', control_type: 'date',
              convert_output: 'date_conversion' },
            { name: 'personalWorkingPatternType' },
            { name: 'hoursInDayNotWorked', type: 'integer' },
            { name: 'standardWorkingPatternId', type: 'integer' },
            { name: 'standardWorkingPattern' },
            { name: 'actualWorkingPattern', type: 'object',
              properties: [
                { name: 'workingPatternType' },
                { name: 'days', type: 'object',
                  properties: [
                    { name: 'sunday', type: 'integer' },
                    { name: 'monday', type: 'integer' },
                    { name: 'tuesday', type: 'integer' },
                    { name: 'wednesday', type: 'integer' },
                    { name: 'thursday', type: 'integer' },
                    { name: 'friday', type: 'integer' },
                    { name: 'saturday', type: 'integer' }
                  ] },
                { name: 'hoursPerDay', type: 'integer' },
                { name: 'workingPatternId', type: 'integer' }
              ] },
            { name: 'customColumns' }
          ] }
      ]
    end,
    employee_life_cycle_history_search_output: lambda do
      [
        { name: 'values', label: "Employee's life-cycle status history",
          type: 'array', of: 'object',
          properties: [
            { name: 'id',
              type: 'integer', control_type: 'integer',
              convert_output: 'integer_conversion' },
            { name: 'reason' },
            { name: 'effectiveDate',
              type: 'date', control_type: 'date',
              convert_output: 'date_conversion' },
            { name: 'endEffectiveDate',
              type: 'date', control_type: 'date',
              convert_output: 'date_conversion' },
            { name: 'isCurrent',
              type: 'boolean', control_type: 'checkbox',
              convert_output: 'boolean_conversion' },
            { name: 'canBeDeleted',
              type: 'boolean', control_type: 'checkbox',
              convert_output: 'boolean_conversion' },
            { name: 'change', type: 'object',
              properties: [
                { name: 'reason' },
                { name: 'changedBy' },
                { name: 'changedById' }
              ] },
            { name: 'creationDate',
              type: 'date', control_type: 'date',
              convert_output: 'date_conversion' },
            { name: 'modificationDate',
              type: 'date', control_type: 'date',
              convert_output: 'date_conversion' },
            { name: 'status' },
            { name: 'employeeStatus' },
            { name: 'reasonType' },
            { name: 'leaveReason' },
            { name: 'customColumns', type: 'object',
              properties: [] }
          ] }
      ]
    end,
    company_list_search_output: lambda do
      item_props = call('company_list_item_schema')
      list_object_props = [
        { name: 'name', label: 'Name' },
        { name: 'label', label: 'Label' },
        { name: 'values',
          label: 'Values',
          type: 'array', of: 'object',
          properties: item_props },
        { name: 'items',
          label: 'Items',
          type: 'array', of: 'object',
          properties: item_props }
      ]

      labels = call('people_field_labels_by_list_key')

      response =
        get('/v1/company/named-lists', 'includeArchived' => true).
        after_error_response(/.*/) do |code, body, header, message|
          if code.to_i == 429
            reset_time = header['x_ratelimit_reset']&.to_i
            sleep_time = reset_time > 0 ? [reset_time - Time.now.to_i + 1, 1].max : 60
            sleep(sleep_time)
            nil
          else
            error("#{message}: #{body}")
          end
        end
      parsed = call('hibob_parse_api_response', response)
      columns =
        if parsed.is_a?(Hash)
          nested = parsed['company_lists'] || parsed[:company_lists]
          nested.is_a?(Hash) ? nested : parsed
        else
          {}
        end
      columns = {} unless columns.is_a?(Hash)

      dynamic_fields = columns.keys.sort.map do |name|
        name_s = name.to_s
        next if name_s == 'company_lists'

        col = columns[name]
        next unless col.is_a?(Hash)

        human = (col['label'] || col[:label]).to_s.presence
        api = (col['name'] || col[:name]).to_s.presence
        api = nil if api.present? && api == name_s
        list_label = human.presence || api.presence || labels[name_s].presence || name_s.labelize
        {
          name: name_s,
          label: list_label,
          type: 'object',
          extends_schema: true,
          properties: list_object_props
        }
      end.compact

      dynamic_fields + [
        { name: 'company_lists',
          label: 'Company lists (grouped)',
          type: 'array', of: 'object',
          properties: list_object_props }
      ]
    end,
    company_report_search_output: lambda do
      [
        { name: 'views', type: 'array', of: 'object',
          properties: [
            { name: 'id', type: 'integer' },
            { name: 'name' },
            { name: 'description' },
            { name: 'createdBy' },
            { name: 'configuration', type: 'object',
              properties: [
                { name: 'instructions', type: 'array', of: 'object',
                  properties: [
                    { name: 'fieldPath' },
                    { name: 'operator' },
                    { name: 'values' }
                  ] },
                { name: 'changes' },
                { name: 'displayPreferences', type: 'object',
                  properties: [
                    { name: 'exportConfiguration' },
                    { name: 'includeFlatJson', type: 'boolean' },
                    { name: 'dateFormat' },
                    { name: 'supportErrorWrapping',
                      type: 'boolean', control_type: 'checkbox',
                      convert_output: 'boolean_conversion' },
                    { name: 'columnsProperties' },
                    { name: 'includeHumanReadable',
                      type: 'boolean', control_type: 'checkbox',
                      convert_output: 'boolean_conversion' }
                  ] },
                { name: 'range', type: 'object',
                  properties: [
                    { name: 'dateValue' },
                    { name: 'type' }
                  ] },
                { name: 'sortBy' },
                { name: 'fields', type: 'array', of: 'string' }
              ] },
            { name: 'isComparable', type: 'boolean' },
            { name: 'type' },
            { name: 'isScheduled', type: 'boolean' },
            { name: 'scheduleStatus' },
            { name: 'modificationDate', type: 'date_time',
              control_type: 'date_time' },
            { name: 'creationDate', type: 'date_time',
              control_type: 'date_time' },
            { name: 'folderId',
              type: 'integer', control_type: 'integer',
              convert_output: 'integer_conversion' }
          ] }
      ]
    end,
    company_field_search_output: lambda do
      [
        { name: 'values', label: 'Company fields',
          type: 'array', of: 'object',
          properties: [
            { name: 'id' },
            { name: 'categoryId' },
            { name: 'categoryDisplayName' },
            { name: 'category' },
            { name: 'name' },
            { name: 'description' },
            { name: 'jsonPath', label: 'JSON path' },
            { name: 'type' },
            { name: 'typeData',
              type: 'object',
              properties: [
                { name: 'listId' }
              ] },
            { name: 'historical',
              type: 'boolean', control_type: 'checkbox',
              convert_output: 'boolean_conversion' }
          ] }
      ]
    end,
    employee_salary_history_search_output: lambda do
      [
        { name: 'values', type: 'array', of: 'object',
          properties: [
            { name: 'id',
              type: 'integer', control_type: 'integer',
              convert_output: 'integer_conversion' },
            { name: 'reason' },
            { name: 'effectiveDate', type: 'date', control_type: 'date',
              convert_output: 'date_conversion' },
            { name: 'base', type: 'object',
              properties: [
                { name: 'value',
                  type: 'integer', control_type: 'integer',
                  convert_output: 'integer_conversion' },
                { name: 'currency' }
              ] },
            { name: 'payPeriod' },
            { name: 'payFrequency' },
            { name: 'endEffectiveDate', type: 'date', control_type: 'date',
              convert_output: 'date_conversion' },
            { name: 'isCurrent',
              type: 'boolean', control_type: 'checkbox',
              convert_output: 'boolean_conversion' },
            { name: 'canBeDeleted',
              type: 'boolean', control_type: 'checkbox',
              convert_output: 'boolean_conversion' },
            { name: 'change', type: 'object',
              properties: [
                { name: 'reason' },
                { name: 'changedBy' },
                { name: 'changedById' }
              ] },
            { name: 'creationDate', type: 'date', control_type: 'date',
              convert_output: 'date_conversion' },
            { name: 'modificationDate', type: 'date', control_type: 'date',
              convert_output: 'date_conversion' },
            { name: 'activeEffectiveDate', type: 'date', control_type: 'date',
              convert_output: 'date_conversion' },
            { name: 'customColumns', type: 'object',
              properties: [] }
          ] }
      ]
    end,
    onboarding_wizard_search_output: lambda do
      [
        { name: 'wizards', type: 'array', of: 'object',
          properties: [
            { name: 'id',
              type: 'integer', control_type: 'integer',
              convert_output: 'integer_conversion' },
            { name: 'name' }
          ] }
      ]
    end,
    employee_get_input: lambda do
      [
        { name: 'identifier', label: 'Employee ID or email',
          optional: false }
      ].concat(call('employees_search_input', '').ignored('showInactive'))
    end,
    employee_new_get_input: lambda do
      [
        { name: 'identifier', label: 'Employee ID or email',
          optional: false },
        {
          name: 'fields',
          label: 'Fields to retrieve',
          pick_list: 'fields_to_retrieve',
          control_type: 'multiselect',
          delimiter: ',',
          optional: true,
          sticky: true,
          type: 'string',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'fields',
            label: 'Fields to retrieve',
            optional: true,
            type: 'string',
            control_type: 'text',
            toggle_hint: 'Use custom value',
            hint: 'Provide a comma-separated list of fields. For basic fields, ' \
                  "add a prefix 'root', for example, 'root.firstName'. " \
                  'For category fields, add the category name as a prefix, ' \
                  "for example, 'work.department'. " \
                  '<a href="https://apidocs.hibob.com/reference/get_people-identifier" ' \
                  'target="_blank">Learn more</a>'
          }
        },
        { name: 'humanReadable', sticky: true,
          extends_schema: true,
          type: 'string', control_type: 'select',
          pick_list: [
            %w[Append APPEND],
            %w[Replace REPLACE]
          ],
          hint: 'Whether to supply human-readable values in JSON instead of ' \
                'machine-readable',
          optional: true,
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'humanReadable', label: 'Human readable',
            extends_schema: true,
            type: 'string', control_type: 'text',
            optional: true, sticky: true,
            hint: 'Whether to supply human-readable values in JSON instead ' \
                  'of machine-readable. Accepted values are <b>APPEND</b> or <b>REPLACE</b>',
            toggle_hint: 'Use custom value'
          } }

      ]
    end,
    company_list_get_input: lambda do
      [
        { name: 'listName', optional: false,
          hint: 'Internal name of the list' },
        { name: 'includeArchived', sticky: true,
          type: 'boolean', control_type: 'checkbox',
          convert_input: 'boolean_conversion',
          hint: 'Whether to include archived items in the response',
          toggle_hint: 'Select from list',
          toggle_field: {
            name: 'includeArchived', label: 'includeArchived',
            type: 'string', control_type: 'text',
            optional: true, sticky: true,
            convert_input: 'boolean_conversion',
            hint: 'Whether to include archived items in the response. ' \
                  'Accepted values are true or false',
            toggle_hint: 'Use custom value'
          } }
      ]
    end,
    company_list_get_output: lambda do
      schema = [
        { name: 'id' },
        { name: 'value' },
        { name: 'name' },
        { name: 'archived',
          type: 'boolean', control_type: 'checkbox',
          convert_output: 'boolean_conversion' },
        { name: 'children',
          type: 'array', of: 'object',
          properties: [] }
      ]
      [
        { name: 'name', label: 'Name' },
        { name: 'label', label: 'Label' },
        { name: 'values', type: 'array', of: 'object',
          properties: schema },
        { name: 'items',
          type: 'array', of: 'object',
          properties: schema }
      ]
    end,
    employee_email_update_input: lambda do
      [
        { name: 'id', label: 'Employee ID',
          optional: false },
        { name: 'email', label: 'New email',
          optional: false }
      ]
    end,
    employee_equity_grant_create_input: lambda do
      call('work_entry_create_input').only('employee_id', 'id', 'reason', 'effectiveDate').
        push(

          { name: 'quantity', optional: false,
            type: 'number', control_type: 'number',
            convert_input: 'float_conversion',
            hint: 'Number of equities granted' },
          { name: 'equityType', optional: false,
            hint: 'The type of the grant' },
          { name: 'vestingCommencementDate', sticky: true,
            type: 'date', control_type: 'date',
            convert_input: 'date_conversion',
            hint: 'Vesting commencement date' },
          { name: 'consentNumber', sticky: true },
          { name: 'grantDate', sticky: true,
            type: 'date', control_type: 'date',
            convert_input: 'date_conversion',
            hint: 'Date the equity was granted' },
          { name: 'optionExpiration', sticky: true,
            type: 'date', control_type: 'date',
            convert_input: 'date_conversion',
            hint: 'Date the options expire' },
          { name: 'exercisePrice', type: 'object', sticky: true,
            properties: [
              { name: 'value', optional: false,
                type: 'number', control_type: 'number',
                convert_input: 'float_conversion' },
              { name: 'currency', optional: false,
                hint: '3 letter currency code e.g. <b>USD</b>' }
            ] },
          { name: 'vestingTerm', sticky: true,
            hint: 'Terms for exercising this grant' },
          { name: 'grantType', sticky: true,
            control_type: 'select',
            pick_list: 'grant_type_list',
            toggle_hint: 'Select from list',
            toggle_field: {
              name: 'grantType', label: 'Grant type',
              optional: true, sticky: true,
              type: 'string', control_type: 'text',
              toggle_hint: 'Use custom value',
              hint: 'Allowed values are Initial Grant, Merit Grant.'
            } },
          { name: 'vestingSchedule', sticky: true,
            type: 'number', control_type: 'number',
            convert_input: 'float_conversion',
            hint: 'Vesting schedule id assigned to this grant' },
          { name: 'grantNumber', sticky: true,
            type: 'number', control_type: 'number',
            convert_input: 'float_conversion',
            hint: 'Grant number for employee' },
          { name: 'grantStatus', sticky: true,
            control_type: 'select',
            pick_list: 'grant_status_list',
            toggle_hint: 'Select from list',
            toggle_field: {
              name: 'grantStatus', label: 'Grant status',
              optional: true, sticky: true,
              type: 'string', control_type: 'text',
              toggle_hint: 'Use custom value',
              hint: 'Allowed values are Granted, Pending Approval.'
            } }

        )
    end,
    company_list_item_update_input: lambda do
      [
        { name: 'listName', optional: false,
          hint: 'Internal name of the list' },
        { name: 'itemId', optional: false,
          hint: 'ID of the list item' },
        { name: 'name', sticky: true,
          hint: 'Name of the item' },
        { name: 'parentId', sticky: true,
          type: 'integer',  control_type: 'integer',
          convert_input: 'integer_conversion',
          hint: 'ID of the new hierarchy parent node' }
      ]
    end,

    employee_update_input: lambda do
      metadata = get('/v1/company/people/fields')
      named_list = get('/v1/company/named-lists')
      people_list = post('/v1/people/search', {})
      [
        { name: 'id', label: 'Employee ID', optional: false,
          hint: 'The HiBob ID of the employee to update' },
        # Root level fields
        { name: 'firstName', label: 'First name', optional: true },
        { name: 'surname', label: 'Last name', optional: true },
        { name: 'secondName', label: 'Middle name', optional: true },
        { name: 'displayName', label: 'Display name', optional: true },
        # Personal Information
        {
          name: 'personal',
          type: 'object',
          label: 'Personal information',
          properties: [
            { name: 'honorific', label: 'Prefix', optional: true,
              control_type: 'select',
              pick_list: call('custom_list', 'honorific', named_list) },
            { name: 'pronouns', label: 'Pronouns', optional: true,
              control_type: 'select',
              pick_list: call('custom_list', 'pronouns', named_list) },
            { name: 'birthDate', label: 'Date of birth', type: 'date', optional: true },
            { name: 'nationality', label: 'Nationality', optional: true,
              control_type: 'multiselect',
              pick_list: call('custom_list', 'nationalities', named_list) },
            {
              name: 'communication',
              type: 'object',
              label: 'Communication',
              properties: [
                { name: 'slackUsername', label: 'Slack username', optional: true },
                { name: 'skypeUsername', label: 'Skype username', optional: true }
              ]
            }
          ].concat(
            begin
              custom_fields = metadata.select do |field|
                field['categoryId'] == 'personal' &&
                field['jsonPath'].start_with?('personal.custom') &&
                field['historical'] == false
              end
              if custom_fields.present?
                [{
                  name: 'custom',
                  type: 'object',
                  label: (
                    metadata.find do |field|
                      field['categoryId'] == 'personal' &&
                      field['jsonPath'].start_with?('personal.custom') &&
                      field['historical'] == false
                    end&.dig('categoryDisplayName')
                  ),
                  properties: call(
                    'generate_properties',
                    custom_fields,
                    named_list,
                    people_list
                  )
                }]
              else
                []
              end
            end
          )
        },
        # Personal Contact Details
        {
          name: 'personalContact',
          type: 'object',
          label: 'Personal contact details',
          properties: [].concat(
            begin
              custom_fields = metadata.select do |field|
                field['categoryId'] == 'personalContact' &&
                field['jsonPath'].start_with?('personalContact.custom') &&
                field['historical'] == false
              end
              if custom_fields.present?
                [{
                  name: 'custom',
                  type: 'object',
                  label: (
                    metadata.find do |field|
                      field['categoryId'] == 'personalContact' &&
                      field['jsonPath'].start_with?('personalContact.custom') &&
                      field['historical'] == false
                    end&.dig('categoryDisplayName')
                  ),
                  properties: call(
                    'generate_properties',
                    custom_fields,
                    named_list,
                    people_list
                  )
                }]
              else
                []
              end
            end
          )
        },
        # Home details
        {
          name: 'home',
          type: 'object',
          label: 'Home',
          properties: [
            { name: 'privateEmail', label: 'Personal email', optional: true },
            { name: 'privatePhone', label: 'Personal phone', optional: true },
            { name: 'mobilePhone', label: 'Personal mobile', optional: true },
            { name: 'familyStatus', label: 'Family status', optional: true,
              control_type: 'select',
              pick_list: call('custom_list', 'familystatus', named_list) },
            { name: 'legalGender', label: 'Legal gender', optional: true,
              control_type: 'select',
              pick_list: call('custom_list', 'legalGender', named_list) },
            {
              name: 'spouse',
              type: 'object',
              label: 'Spouse information',
              properties: [
                { name: 'firstName', label: 'Spouse first name', optional: true },
                { name: 'surname', label: 'Spouse last name', optional: true },
                { name: 'birthDate', label: 'Spouse birth date', type: 'date', optional: true },
                { name: 'gender', label: 'Spouse gender', optional: true,
                  control_type: 'select',
                  pick_list: call('custom_list', 'legalGender', named_list) }
              ]
            }
          ].concat(
            begin
              custom_fields = metadata.select do |field|
                field['categoryId'] == 'home' &&
                field['jsonPath'].start_with?('home.custom') &&
                field['historical'] == false
              end
              if custom_fields.present?
                [{
                  name: 'custom',
                  type: 'object',
                  label: (
                    metadata.find do |field|
                      field['categoryId'] == 'home' &&
                      field['jsonPath'].start_with?('home.custom') &&
                      field['historical'] == false
                    end&.dig('categoryDisplayName')
                  ),
                  properties: call(
                    'generate_properties',
                    custom_fields,
                    named_list,
                    people_list
                  )
                }]
              else
                []
              end
            end
          )
        },
        # Work Details
        {
          name: 'work',
          type: 'object',
          label: 'Work',
          properties: [
            { name: 'employeeIdInCompany', label: 'Employee ID', type: 'number', optional: true },
            { name: 'workMobile', label: 'Work mobile', optional: true },
            { name: 'workPhone', label: 'Work phone', optional: true }
          ].concat(
            begin
              custom_fields = metadata.select do |field|
                field['categoryId'] == 'work' &&
                field['jsonPath'].start_with?('work.custom') &&
                field['historical'] == false
              end
              if custom_fields.present?
                [{
                  name: 'custom',
                  type: 'object',
                  label: (
                    metadata.find do |field|
                      field['categoryId'] == 'work' &&
                      field['jsonPath'].start_with?('work.custom') &&
                      field['historical'] == false
                    end&.dig('categoryDisplayName')
                  ),
                  properties: call(
                    'generate_properties',
                    custom_fields,
                    named_list,
                    people_list
                  )
                }]
              else
                []
              end
            end
          )
        },
        # Work Contact Details
        {
          name: 'workContact',
          type: 'object',
          label: 'Work contact details',
          properties: [].concat(
            begin
              custom_fields = metadata.select do |field|
                field['categoryId'] == 'workContact' &&
                field['jsonPath'].start_with?('workContact.custom') &&
                field['historical'] == false
              end
              if custom_fields.present?
                [{
                  name: 'custom',
                  type: 'object',
                  label: (
                    metadata.find do |field|
                      field['categoryId'] == 'workContact' &&
                      field['jsonPath'].start_with?('workContact.custom') &&
                      field['historical'] == false
                    end&.dig('categoryDisplayName')
                  ),
                  properties: call(
                    'generate_properties',
                    custom_fields,
                    named_list,
                    people_list
                  )
                }]
              else
                []
              end
            end
          )
        },
        # Equity Details
        {
          name: 'equity',
          type: 'object',
          label: 'Equity information',
          properties: [].concat(
            begin
              custom_fields = metadata.select do |field|
                field['categoryId'] == 'equity' &&
                field['jsonPath'].start_with?('equity.custom') &&
                field['historical'] == false
              end
              if custom_fields.present?
                [{
                  name: 'custom',
                  type: 'object',
                  label: (
                    metadata.find do |field|
                      field['categoryId'] == 'equity' &&
                      field['jsonPath'].start_with?('equity.custom') &&
                      field['historical'] == false
                    end&.dig('categoryDisplayName')
                  ),
                  properties: call(
                    'generate_properties',
                    custom_fields,
                    named_list,
                    people_list
                  )
                }]
              else
                []
              end
            end
          )
        },
        # Right to Work
        {
          name: 'rightToWork',
          type: 'object',
          label: 'Right to work',
          properties: [].concat(
            begin
              custom_fields = metadata.select do |field|
                field['categoryId'] == 'rightToWork' &&
                field['jsonPath'].start_with?('rightToWork.custom') &&
                field['historical'] == false
              end
              if custom_fields.present?
                [{
                  name: 'custom',
                  type: 'object',
                  label: (
                    metadata.find do |field|
                      field['categoryId'] == 'rightToWork' &&
                      field['jsonPath'].start_with?('rightToWork.custom') &&
                      field['historical'] == false
                    end&.dig('categoryDisplayName')
                  ),
                  properties: call(
                    'generate_properties',
                    custom_fields,
                    named_list,
                    people_list
                  )
                }]
              else
                []
              end
            end
          )
        },
        # About Information
        {
          name: 'about',
          type: 'object',
          label: 'About information',
          properties: [
            { name: 'about', label: 'About', type: 'text-area', optional: true },
            { name: 'hobbies', label: 'Hobbies', optional: true,
              control_type: 'multiselect',
              pick_list: call('custom_list', 'hobbies', named_list) },
            { name: 'superpowers', label: 'Superpowers', optional: true,
              control_type: 'multiselect',
              pick_list: call('custom_list', 'superpowers', named_list) },
            { name: 'foodPreferences', label: 'Food preferences', optional: true,
              control_type: 'multiselect',
              pick_list: call('custom_list', 'foodPreferences', named_list) },
            {
              name: 'socialData',
              type: 'object',
              label: 'Social media',
              properties: [
                { name: 'facebook', label: 'Facebook', optional: true },
                { name: 'twitter', label: 'Twitter', optional: true },
                { name: 'linkedin', label: 'LinkedIn', optional: true }
              ]
            }
          ].concat(
            begin
              custom_fields = metadata.select do |field|
                field['categoryId'] == 'about' &&
                field['jsonPath'].start_with?('about.custom') &&
                field['historical'] == false
              end
              if custom_fields.present?
                [{
                  name: 'custom',
                  type: 'object',
                  label: (
                    metadata.find do |field|
                      field['categoryId'] == 'about' &&
                      field['jsonPath'].start_with?('about.custom') &&
                      field['historical'] == false
                    end&.dig('categoryDisplayName')
                  ),
                  properties: call(
                    'generate_properties',
                    custom_fields,
                    named_list,
                    people_list
                  )
                }]
              else
                []
              end
            end
          )
        },
        # Training Information
        {
          name: 'training',
          type: 'object',
          label: 'Training information',
          properties: [].concat(
            begin
              custom_fields = metadata.select do |field|
                field['categoryId'] == 'training' &&
                field['jsonPath'].start_with?('training.custom') &&
                field['historical'] == false
              end
              if custom_fields.present?
                [{
                  name: 'custom',
                  type: 'object',
                  label: (
                    metadata.find do |field|
                      field['categoryId'] == 'training' &&
                      field['jsonPath'].start_with?('training.custom') &&
                      field['historical'] == false
                    end&.dig('categoryDisplayName')
                  ),
                  properties: call(
                    'generate_properties',
                    custom_fields,
                    named_list,
                    people_list
                  )
                }]
              else
                []
              end
            end
          )
        },
        # User Data Information
        {
          name: 'userData',
          type: 'object',
          label: 'User data information',
          properties: [].concat(
            begin
              custom_fields = metadata.select do |field|
                field['categoryId'] == 'userData' &&
                field['jsonPath'].start_with?('userData.custom') &&
                field['historical'] == false
              end
              if custom_fields.present?
                [{
                  name: 'custom',
                  type: 'object',
                  label: (
                    metadata.find do |field|
                      field['categoryId'] == 'userData' &&
                      field['jsonPath'].start_with?('userData.custom') &&
                      field['historical'] == false
                    end&.dig('categoryDisplayName')
                  ),
                  properties: call(
                    'generate_properties',
                    custom_fields,
                    named_list,
                    people_list
                  )
                }]
              else
                []
              end
            end
          )
        },
        # Financial Information
        {
          name: 'financial',
          type: 'object',
          label: 'Financial information',
          properties: [
            { name: 'accountName', label: 'Account name', optional: true },
            { name: 'routingNumber', label: 'Routing number', optional: true },
            { name: 'accountnumber', label: 'Account number', optional: true },
            { name: 'bankName', label: 'Bank name', optional: true },
            { name: 'bankAccountType', label: 'Bank account type', optional: true,
              control_type: 'select',
              pick_list: call('custom_list', 'bankaccounttypes', named_list) },
            { name: 'bankAddress', label: 'Branch address', optional: true },
            { name: 'swift', label: 'SWIFT code', optional: true },
            { name: 'iban', label: 'IBAN', optional: true },
            { name: 'sortcode', label: 'Sort code', optional: true },
            { name: 'accountType', label: 'Account type', optional: true,
              control_type: 'select',
              pick_list: call('custom_list', 'accountType', named_list) },
            { name: 'passportNumber', label: 'Passport number', optional: true },
            { name: 'identificationNumber', label: 'National ID', optional: true }
          ].concat(
            begin
              custom_fields = metadata.select do |field|
                field['categoryId'] == 'financial' &&
                field['jsonPath'].start_with?('financial.custom') &&
                field['historical'] == false
              end
              if custom_fields.present?
                [{
                  name: 'custom',
                  type: 'object',
                  label: (
                    metadata.find do |field|
                      field['categoryId'] == 'financial' &&
                      field['jsonPath'].start_with?('financial.custom') &&
                      field['historical'] == false
                    end&.dig('categoryDisplayName')
                  ),
                  properties: call(
                    'generate_properties',
                    custom_fields,
                    named_list,
                    people_list
                  )
                }]
              else
                []
              end
            end
          )
        },
        # Address
        {
          name: 'address',
          type: 'object',
          label: 'Address information',
          properties: [].concat(
            begin
              custom_fields = metadata.select do |field|
                field['categoryId'] == 'address' &&
                field['jsonPath'].start_with?('address.custom') &&
                field['historical'] == false
              end
              if custom_fields.present?
                [{
                  name: 'custom',
                  type: 'object',
                  label: (
                    metadata.find do |field|
                      field['categoryId'] == 'address' &&
                      field['jsonPath'].start_with?('address.custom') &&
                      field['historical'] == false
                    end&.dig('categoryDisplayName')
                  ),
                  properties: call(
                    'generate_properties',
                    custom_fields,
                    named_list,
                    people_list
                  )
                }]
              else
                []
              end
            end
          )
        },
        # Identification
        {
          name: 'identification',
          type: 'object',
          label: 'Identification',
          properties: [
            { name: 'ssnSerialNumber', label: 'SSN last 4 digits', optional: true },
            { name: 'ssn', label: 'SSN', optional: true }
          ].concat(
            begin
              custom_fields = metadata.select do |field|
                field['categoryId'] == 'identification' &&
                field['jsonPath'].start_with?('identification.custom') &&
                field['historical'] == false
              end
              if custom_fields.present?
                [{
                  name: 'custom',
                  type: 'object',
                  label: (
                    metadata.find do |field|
                      field['categoryId'] == 'identification' &&
                      field['jsonPath'].start_with?('identification.custom') &&
                      field['historical'] == false
                    end&.dig('categoryDisplayName')
                  ),
                  properties: call(
                    'generate_properties',
                    custom_fields,
                    named_list,
                    people_list
                  )
                }]
              else
                []
              end
            end
          )
        },
        # Payroll (limited non-historical fields)
        {
          name: 'payroll',
          type: 'object',
          label: 'Payroll information',
          properties: [
            { name: 'nin', label: 'NI number', optional: true },
            { name: 'additionalPensionContribution', label: 'Additional pension contribution',
              type: 'number', optional: true },
            { name: 'taxCode', label: 'Tax code', optional: true }
          ].concat(
            begin
              custom_fields = metadata.select do |field|
                field['categoryId'] == 'payroll' &&
                field['jsonPath'].start_with?('payroll.custom') &&
                field['historical'] == false
              end
              if custom_fields.present?
                [{
                  name: 'custom',
                  type: 'object',
                  label: (
                    metadata.find do |field|
                      field['categoryId'] == 'payroll' &&
                      field['jsonPath'].start_with?('payroll.custom') &&
                      field['historical'] == false
                    end&.dig('categoryDisplayName')
                  ),
                  properties: call(
                    'generate_properties',
                    custom_fields,
                    named_list,
                    people_list
                  )
                }]
              else
                []
              end
            end
          )
        },
        # Emergency Contact
        {
          name: 'emergency',
          type: 'object',
          label: 'Emergency contact',
          properties: [
            { name: 'firstName', label: 'Emergency contact first name', optional: true },
            { name: 'secondName', label: 'Emergency contact middle name', optional: true },
            { name: 'surname', label: 'Emergency contact cast came', optional: true },
            { name: 'relation', label: 'Emergency contact relationship', optional: true,
              control_type: 'select',
              pick_list: call('custom_list', 'relation', named_list) },
            { name: 'phone', label: 'Emergency contact phone', optional: true },
            { name: 'mobilePhone', label: 'Emergency contact  mobile', optional: true },
            { name: 'email', label: 'Emergency contact email', optional: true },
            { name: 'address', label: 'Emergency contact address', optional: true },
            { name: 'city', label: 'Emergency contact city', optional: true },
            { name: 'postCode', label: 'Emergency contact post code', optional: true },
            { name: 'country', label: 'Emergency contact country', optional: true,
              control_type: 'select',
              pick_list: call('custom_list', 'countries', named_list) }
          ].concat(
            begin
              custom_fields = metadata.select do |field|
                field['categoryId'] == 'emergency' &&
                field['jsonPath'].start_with?('emergency.custom') &&
                field['historical'] == false
              end
              if custom_fields.present?
                [{
                  name: 'custom',
                  type: 'object',
                  label: (
                    metadata.find do |field|
                      field['categoryId'] == 'emergency' &&
                      field['jsonPath'].start_with?('emergency.custom') &&
                      field['historical'] == false
                    end&.dig('categoryDisplayName')
                  ),
                  properties: call(
                    'generate_properties',
                    custom_fields,
                    named_list,
                    people_list
                  )
                }]
              else
                []
              end
            end
          )
        },
        # Employee Data
        {
          name: 'employee', # Need to cross-verify
          type: 'object',
          label: 'Employee data',
          properties: [
            { name: 'legalSex', label: 'Legal sex', optional: true,
              control_type: 'select',
              pick_list: call('custom_list', 'legalGender', named_list) },
            { name: 'veteranStatus', label: 'Veteran status', optional: true,
              control_type: 'multiselect',
              pick_list: call('custom_list', 'veteranStatus', named_list) },
            { name: 'ethnicities', label: 'Ethnicities', optional: true,
              control_type: 'multiselect',
              pick_list: call('custom_list', 'ethnicities', named_list) }
          ].concat(
            begin
              custom_fields = metadata.select do |field|
                field['categoryId'] == 'employee' &&
                field['jsonPath'].start_with?('employee.custom') &&
                field['historical'] == false
              end
              if custom_fields.present?
                [{
                  name: 'custom',
                  type: 'object',
                  label: (
                    metadata.find do |field|
                      field['categoryId'] == 'employee' &&
                      field['jsonPath'].start_with?('employee.custom') &&
                      field['historical'] == false
                    end&.dig('categoryDisplayName')
                  ),
                  properties: call(
                    'generate_properties',
                    custom_fields,
                    named_list,
                    people_list
                  )
                }]
              else
                []
              end
            end
          )
        },
        # Employment fields
        {
          name: 'employment',
          type: 'object',
          label: 'Employment information',
          properties: [].concat(
            # Only add custom object if there are custom fields
            begin
              custom_fields = metadata.select do |field|
                field['categoryId'] == 'employment' &&
                field['jsonPath'].start_with?('employment.custom') &&
                field['historical'] == false
              end
              if custom_fields.present?
                [{
                  name: 'custom',
                  type: 'object',
                  label: (
                    metadata.find do |field|
                      field['categoryId'] == 'employment' &&
                      field['jsonPath'].start_with?('employment.custom') &&
                      field['historical'] == false
                    end&.dig('categoryDisplayName')
                  ),
                  properties: call(
                    'generate_properties',
                    custom_fields,
                    named_list,
                    people_list
                  )
                }]
              else
                []
              end
            end
          )
        },
        # EEO Information
        {
          name: 'eeo',
          type: 'object',
          label: 'EEO information',
          properties: [
            { name: 'ethnicity', label: 'Ethnicity', optional: true,
              control_type: 'select',
              pick_list: call('custom_list', 'ethnicity', named_list) },
            { name: 'jobCategory', label: 'Job category', optional: true,
              control_type: 'select',
              pick_list: call('custom_list', 'jobCategory', named_list) },
            { name: 'custom',
              type: 'object',
              label: metadata.find do |field|
                field['categoryId'] == 'eeo' &&
                  field['jsonPath'].start_with?('eeo.custom') &&
                  field['historical'] == false
              end&.dig('categoryDisplayName'),
              properties: call(
                'generate_properties',
                metadata.select do |field|
                  field['categoryId'] == 'eeo' &&
                  field['jsonPath'].start_with?('eeo.custom') &&
                  field['historical'] == false
                end, named_list, people_list
              ) }
          ]
        },
        # Temporary Address
        {
          name: 'temporaryAddress',
          type: 'object',
          label: 'Temporary address',
          properties: [
            { name: 'line1', label: 'Temporary address line 1', optional: true },
            { name: 'line2', label: 'Temporary address line 2', optional: true },
            { name: 'city', label: 'Temporary city', optional: true },
            { name: 'usaState', label: 'Temporary state/province/region', optional: true },
            { name: 'country', label: 'Temporary country', optional: true,
              control_type: 'select',
              pick_list: call('custom_list', 'countries', named_list) },
            { name: 'postCode', label: 'Temporary zip/post/postal Code', optional: true }
          ].concat(
            begin
              custom_fields = metadata.select do |field|
                field['categoryId'] == 'temporaryAddress' &&
                field['jsonPath'].start_with?('temporaryAddress.custom') &&
                field['historical'] == false
              end

              if custom_fields.present?
                [{
                  name: 'custom',
                  type: 'object',
                  label: (
                    metadata.find do |field|
                      field['categoryId'] == 'temporaryAddress' &&
                      field['jsonPath'].start_with?('temporaryAddress.custom') &&
                      field['historical'] == false
                    end&.dig('categoryDisplayName')
                  ),
                  properties: call(
                    'generate_properties',
                    custom_fields,
                    named_list,
                    people_list
                  )
                }]
              else
                []
              end
            end
          )
        },
        # Basic info
        {
          name: 'custom',
          type: 'object',
          label: 'Custom fields',
          properties: (
            basic_info_fields = metadata.select do |field|
              field['categoryDisplayName'] == 'Basic info' &&
                field['jsonPath'].start_with?('custom.') &&
                field['historical'] == false
            end

            other_custom_fields = metadata.select do |field|
              field['id'].start_with?('custom.') &&
                field['jsonPath'].start_with?('custom.') &&
                field['historical'] == false &&
                field['categoryDisplayName'] != 'Basic info'
            end

            props = []

            if basic_info_fields.present?
              props.concat(
                call(
                  'generate_properties',
                  basic_info_fields,
                  named_list,
                  people_list
                )
              )
            end

            if other_custom_fields.present?
              props.concat(
                other_custom_fields.group_by { |f| f['category'] }.map do |category, fields|
                  {
                    name: category,
                    type: 'object',
                    label: fields.first['categoryDisplayName'],
                    properties: call(
                      'generate_properties',
                      fields,
                      named_list,
                      people_list
                    )
                  }
                end
              )
            end

            props.presence || []
          )
        }
      ]
    end,

    parse_multiselect_value: lambda do |value|
      if value.is_a?(String)
        if value.start_with?('[') && value.end_with?(']')
          begin
            JSON.parse(value)
          rescue JSON::ParserError
            clean_value = value.gsub(/^\[|\]$/, '').gsub(/["\\\s]/, '')
            clean_value.split(',')
          end
        else
          value.split(',').map(&:strip)
        end
      else
        value
      end
    end,

    handle_multiselect_fields_new: lambda do |input|
      normalize_multiselect = lambda do |hash|
        hash.each do |field, field_value|
          next unless field_value.present?

          if field_value.is_a?(String) && field_value.strip.start_with?('[')
            parsed = call('parse_multiselect_value', field_value)
            hash[field] = parsed.is_a?(Array) ? parsed.map(&:to_s) : [parsed.to_s]
          elsif field_value.is_a?(Array)
            hash[field] = field_value.map(&:to_s)
          end
        end
      end

      input.each_value do |section_value|
        next unless section_value.is_a?(Hash)

        section_value.each do |subfield, subvalue|
          if subvalue.is_a?(Hash)
            normalize_multiselect.call(subvalue)
            next
          end

          if subvalue.is_a?(String) && subvalue.strip.start_with?('[')
            parsed = call('parse_multiselect_value', subvalue)
            section_value[subfield] = parsed.is_a?(Array) ? parsed.map(&:to_s) : [parsed.to_s]
            next
          end

          next unless subvalue.is_a?(Array)

          section_value[subfield] = subvalue.map(&:to_s)
        end
      end

      input
    end,

    convert_custom_field_types: lambda do |input|
      if input['custom'].present? && input['custom']['field_1695912389080'].present?
        input['custom']['field_1695912389080'] = input['custom']['field_1695912389080'].to_i
      end
      input
    end,

    convert_currency_format: lambda do |input|
      if input.dig('custom', 'field_1695912376688', 'currency').present?
        currency_string = input['custom']['field_1695912376688']['currency']
        parts = currency_string.strip.split
        if parts.length >= 2
          amount = parts[0].to_f
          currency_code = parts[1]
          input['custom']['field_1695912376688'] = {
            'value' => amount,
            'currency' => currency_code
          }
        end
      end
      input
    end
  }
}
